import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import PageLayout from "@/components/layout/page-layout";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Download, Plus, ClipboardList } from "lucide-react";
import { Link } from "wouter";
import type { TimeEntryWithProject, Project } from "@shared/schema";
import EnhancedTimeEntryModal from "@/components/time/enhanced-time-entry-modal";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { formatPSTDate } from "@shared/timezone";
import Header from "@/components/layout/header";

export default function TimeLog() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [dateRange, setDateRange] = useState<string>("month");
  const [editingEntry, setEditingEntry] = useState<TimeEntryWithProject | null>(null);

  // Debug logging for state changes
  console.log('🕒 [TIME-LOG] Component state:', {
    selectedProject,
    dateRange,
    isAuthenticated,
    isLoading
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch projects
  const { data: projects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    enabled: isAuthenticated,
    retry: 3,
    staleTime: 5 * 60 * 1000, // 5 minutes
    select: (data) => Array.isArray(data) ? data : [],
  });

  // Calculate date filters
  const getDateFilters = () => {
    const now = new Date();
    const todayPST = now.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });
    const today = new Date(todayPST + 'T00:00:00');

    switch (dateRange) {
      case "today":
        return {
          startDate: todayPST,
          endDate: todayPST,
        };
      case "week": {
        const startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
      case "quarter": {
        const startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 3);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
      default: { // month
        const startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 1);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
    }
  };

  // Fetch time entries
  const { startDate, endDate } = getDateFilters();
  const { data: timeEntries, isLoading: entriesLoading, refetch } = useQuery<TimeEntryWithProject[]>({
    queryKey: ["/api/time-entries", { projectId: selectedProject, startDate, endDate }],
    queryFn: async () => {
      console.log('🕒 [TIME-LOG] Fetching time entries with params:', {
        projectId: selectedProject,
        startDate,
        endDate
      });

      const params = new URLSearchParams({
        projectId: selectedProject,
        startDate,
        endDate,
      });
      const response = await fetch(`/api/time-entries?${params}`);

      console.log('🕒 [TIME-LOG] API response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('🕒 [TIME-LOG] API error:', errorText);
        throw new Error(`${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('🕒 [TIME-LOG] Received time entries:', data?.length || 0);

      return Array.isArray(data) ? data : [];
    },
    enabled: isAuthenticated,
    select: (data) => {
      console.log('🕒 [TIME-LOG] Selected time entries:', data?.length || 0);
      return Array.isArray(data) ? data : [];
    },
  });

  const handleDeleteEntry = async (entryId: string) => {
    if (!confirm('Are you sure you want to delete this time entry?')) {
      return;
    }

    try {
      await apiRequest(`/api/time-entries/${entryId}`, 'DELETE');
      toast({
        title: "Success",
        description: "Time entry deleted successfully",
      });
      refetch();
    } catch (error) {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }

      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      const isNotFound = errorMessage.includes('404');

      toast({
        title: "Error",
        description: isNotFound
          ? "Time entry not found or already deleted"
          : `Failed to delete time entry: ${errorMessage}`,
        variant: "destructive",
      });

      // Refresh the list even if delete failed (item might already be gone)
      if (isNotFound) {
        refetch();
      }
    }
  };

  // Helper function to format time
  const formatTime = (time: string | Date | null | undefined) => {
    try {
      if (!time) return '—';

      // If it's already in HH:MM format (string), return as is
      if (typeof time === 'string') {
        // Check if it matches HH:MM pattern
        if (/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time)) {
          return time;
        }
        // Try to parse as date if it's a full datetime string
        const date = new Date(time);
        if (!isNaN(date.getTime())) {
          return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
      }

      // If it's a Date object
      if (time instanceof Date && !isNaN(time.getTime())) {
        return time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }

      return '—';
    } catch {
      return '—';
    }
  };

  const formatDate = (dateString: string | number | Date) => {
    try {
      // Handle string dates
      if (typeof dateString === 'string') {
        // If it's already in YYYY-MM-DD format, use formatPSTDate directly
        if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
          return formatPSTDate(dateString);
        }
        // Otherwise try to parse and convert to YYYY-MM-DD format
        const date = new Date(dateString);
        if (!isNaN(date.getTime())) {
          const dateStr = date.toISOString().split('T')[0];
          return formatPSTDate(dateStr);
        } else {
          console.warn('Invalid date string in time log:', dateString);
          return 'Invalid Date';
        }
      }

      // Handle Date objects or numbers
      const date = new Date(dateString);
      if (!isNaN(date.getTime())) {
        const dateStr = date.toISOString().split('T')[0]; // Get YYYY-MM-DD format
        return formatPSTDate(dateStr);
      } else {
        console.warn('Invalid date in time log:', dateString);
        return 'Invalid Date';
      }
    } catch (error) {
      console.error('Error formatting date in time log:', error, dateString);
      return 'Invalid Date';
    }
  };

  const getProjectColor = (color?: string) => {
    const colors = {
      '#1976D2': 'bg-primary/10 text-primary',
      '#388E3C': 'bg-green-100 text-green-700',
      '#F57C00': 'bg-orange-100 text-orange-700',
      '#D32F2F': 'bg-red-100 text-red-700',
    };
    return colors[(color || '#1976D2') as keyof typeof colors] || 'bg-primary/10 text-primary';
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="md:flex md:items-center md:justify-between mb-8">
          <div className="flex-1 min-w-0">
            <div className="flex items-center">
              <ClipboardList className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                  Time Log
                </h2>
                <p className="mt-1 text-sm text-gray-500">
                  View and manage your time entries
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Filter by Project</label>
                  <Select value={selectedProject} onValueChange={setSelectedProject}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="All Projects" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Projects</SelectItem>
                      {Array.isArray(projects) && projects.filter(project =>
                        project?.id &&
                        typeof project.id === 'string' &&
                        project.id.trim() !== '' &&
                        project.name &&
                        typeof project.name === 'string' &&
                        project.name.trim() !== ''
                      ).map(project => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                      <SelectItem value="quarter">This Quarter</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
                <Link href="/time-entry">
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Entry
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Time Entries Table */}
        <Card>
          <CardContent className="p-0">
            {entriesLoading ? (
              <div className="p-8 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading time entries...</p>
              </div>
            ) : !timeEntries || timeEntries.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-muted-foreground mb-4">No time entries found for the selected filters.</p>
                <Link href="/time-entry">
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Entry
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Project</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Project #</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Task</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Time</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Time</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                      <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {(timeEntries || []).map((entry) => (
                      <tr key={entry.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatDate(entry.date)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className="bg-primary/10 text-primary">
                            {entry.project?.name || 'Unknown Project'}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {entry.project?.project_number ? (
                            <Badge variant="outline" className="bg-gray-50 text-gray-700">
                              {entry.project.project_number}
                            </Badge>
                          ) : (
                            <span className="text-gray-400 text-xs">—</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {entry.task?.name || "—"}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900 max-w-xs truncate">
                          {entry.description || "No description"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatTime(entry.start_time)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatTime(entry.end_time)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {entry.duration}h
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingEntry(entry)}
                              className="text-primary hover:text-primary/80"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteEntry(entry.id)}
                              className="text-destructive hover:text-destructive/80"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Modal */}
        {editingEntry && (
          <EnhancedTimeEntryModal
            entry={editingEntry}
            onClose={() => setEditingEntry(null)}
            onSuccess={() => {
              setEditingEntry(null);
              refetch();
            }}
          />
        )}
      </main>
    </div>
  );
}