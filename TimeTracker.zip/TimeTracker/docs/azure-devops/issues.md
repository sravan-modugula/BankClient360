

# FMB TimeTracker - Issues & Bugs

## Critical Issues

### BUG001: SAML Certificate Path Resolution Failure
**Priority:** Critical  
**Severity:** Blocker  
**Component:** Authentication  
**Assigned To:** Backend Team  
**Sprint:** Current

**Description:**
Application fails to start due to incorrect SAML certificate path resolution in containerized environment.

**Error Message:**
```
SAML certificate file not found: /home/runner/workspace/C:/fmb-timetracker/saml_cert.pem
```

**Impact:**
- Prevents application startup
- Blocks all user authentication
- Affects development and production environments

**Steps to Reproduce:**
1. Start the application in development mode
2. Application attempts to load SAML certificate
3. Certificate path resolution fails
4. Application exits with critical error

**Expected Behavior:**
Application should correctly resolve certificate path based on environment

**Actual Behavior:**
Certificate path contains mixed Windows/Linux path separators

**Root Cause:**
Path resolution logic assumes Windows environment but runs in Linux container

**Proposed Solution:**
- Implement environment-aware path resolution
- Use relative paths instead of absolute paths
- Add certificate path validation during startup

**Acceptance Criteria:**
- [ ] Certificate loads successfully in all environments
- [ ] Clear error messages when certificate is missing
- [ ] Fallback mechanism for certificate loading
- [ ] Unit tests for path resolution logic

---

## High Priority Issues

### BUG002: Duplicate executeQuery Method in FmbStorage
**Priority:** High  
**Severity:** Major  
**Component:** Database Layer  
**Assigned To:** Backend Team  
**Sprint:** Current

**Description:**
TypeScript compilation produces warnings due to duplicate `executeQuery` method definitions in the FmbStorage class.

**Error Message:**
```
▲ [WARNING] Duplicate member "executeQuery" in class body [duplicate-class-member]
```

**Impact:**
- Build warnings in production
- Potential runtime confusion
- Code maintainability issues
- TypeScript compilation issues

**Steps to Reproduce:**
1. Run `npm run build`
2. Observe TypeScript compilation warnings
3. Check FmbStorage class definition

**Expected Behavior:**
Single, well-defined executeQuery method

**Actual Behavior:**
Two executeQuery methods with different signatures exist

**Root Cause:**
Method was duplicated during refactoring without proper cleanup

**Proposed Solution:**
- Remove duplicate method definition
- Consolidate functionality into single method
- Update all callers to use unified interface

**Acceptance Criteria:**
- [ ] No TypeScript compilation warnings
- [ ] Single executeQuery method with proper typing
- [ ] All database operations work correctly
- [ ] Method signature is backwards compatible

---

### BUG003: Task Creation Disabled for "All Projects" Selection
**Priority:** High  
**Severity:** Major  
**Component:** Task Management  
**Assigned To:** Frontend Team  
**Sprint:** Next

**Description:**
Create task button remains disabled when "All Projects" is selected, preventing users from creating tasks without first selecting a specific project.

**Impact:**
- Poor user experience
- Workflow interruption
- User confusion about task creation process

**Steps to Reproduce:**
1. Navigate to Tasks page
2. Select "All Projects" from project filter
3. Click "Create Task" button
4. Button remains disabled

**Expected Behavior:**
User should be able to create task and select project in modal

**Actual Behavior:**
Create task button is disabled when "All Projects" is selected

**Root Cause:**
Button enable logic incorrectly treats "all" as invalid project selection

**Proposed Solution:**
- Update button enable logic to allow task creation
- Show project selection in task creation modal
- Improve UX flow for task creation

**Acceptance Criteria:**
- [ ] Create task button enabled for "All Projects"
- [ ] Project selection available in task modal
- [ ] Validation prevents task creation without project
- [ ] Clear error messages for invalid selections

---

## Medium Priority Issues

### BUG004: Intermittent Session Store Connection Failures
**Priority:** Medium  
**Severity:** Major  
**Component:** Session Management  
**Assigned To:** Backend Team  
**Sprint:** Next

**Description:**
Random session store connection failures cause users to be unexpectedly logged out.

**Error Pattern:**
```
SESSION-Failed to connect to session store
```

**Impact:**
- User session interruption
- Data loss in unsaved forms
- Poor user experience
- Productivity impact

**Steps to Reproduce:**
1. Login and work normally
2. Random session disconnections occur
3. User redirected to login page
4. Loss of unsaved work

**Expected Behavior:**
Stable session persistence throughout user session

**Actual Behavior:**
Intermittent session store connectivity issues

**Root Cause:**
- Database connection pool exhaustion
- Network timeout issues
- Session cleanup conflicts

**Proposed Solution:**
- Implement session store health monitoring
- Add connection retry logic
- Improve session cleanup procedures
- Add session recovery mechanisms

**Acceptance Criteria:**
- [ ] Session store health monitoring
- [ ] Automatic retry on connection failure
- [ ] User notification of session issues
- [ ] Session data preservation during reconnection

---

### BUG005: Inconsistent Frontend API Error Handling
**Priority:** Medium  
**Severity:** Minor  
**Component:** Frontend  
**Assigned To:** Frontend Team  
**Sprint:** Backlog

**Description:**
API error responses are not consistently handled across the application, leading to generic error messages.

**Impact:**
- Poor user experience
- Difficulty troubleshooting issues
- Inconsistent error presentation
- User confusion about error causes

**Examples:**
- Generic "Something went wrong" messages
- API error details not displayed
- Inconsistent error toast styling
- Missing error context information

**Expected Behavior:**
Consistent, informative error messages with appropriate actions

**Actual Behavior:**
Inconsistent error handling and messaging

**Root Cause:**
- Lack of centralized error handling
- Inconsistent error response parsing
- Missing error message mappings

**Proposed Solution:**
- Implement centralized error handling
- Create error message dictionary
- Standardize error response format
- Add error context information

**Acceptance Criteria:**
- [ ] Centralized error handling utility
- [ ] Consistent error message format
- [ ] Contextual error information
- [ ] User-friendly error actions

---

## Technical Debt Issues

### TECH001: Database Query Performance Optimization
**Priority:** Medium  
**Severity:** Minor  
**Component:** Database Layer  
**Assigned To:** Backend Team  
**Sprint:** Backlog

**Description:**
Several database queries lack proper indexing and optimization, leading to slower response times.

**Impact:**
- Slower application performance
- Poor user experience with large datasets
- Potential scalability issues

**Areas for Improvement:**
- Time entries queries with date range filters
- Project employee assignment queries
- Dashboard statistics aggregation
- Report generation queries

**Proposed Solution:**
- Add database indexes for frequently queried columns
- Optimize query structure and joins
- Implement query result caching
- Add query performance monitoring

**Acceptance Criteria:**
- [ ] Query execution time under 100ms for common operations
- [ ] Database indexes on frequently searched columns
- [ ] Query performance monitoring dashboard
- [ ] Caching strategy for expensive queries

---

### TECH002: Frontend Component Refactoring
**Priority:** Low  
**Severity:** Minor  
**Component:** Frontend  
**Assigned To:** Frontend Team  
**Sprint:** Backlog

**Description:**
Several React components have grown large and contain duplicate logic that should be refactored.

**Impact:**
- Code maintainability issues
- Duplicate business logic
- Increased bundle size
- Testing complexity

**Components Needing Refactoring:**
- Time entry forms (multiple similar components)
- Project management modals
- Report generation interfaces
- Dashboard widgets

**Proposed Solution:**
- Extract common hooks and utilities
- Create reusable form components
- Implement consistent state management
- Reduce component complexity

**Acceptance Criteria:**
- [ ] Reduced component line count by 30%
- [ ] Common logic extracted to hooks
- [ ] Improved test coverage
- [ ] Better component reusability

---

### TECH003: API Documentation and Testing
**Priority:** Low  
**Severity:** Minor  
**Component:** Backend  
**Assigned To:** Backend Team  
**Sprint:** Backlog

**Description:**
API endpoints lack comprehensive documentation and automated testing coverage.

**Impact:**
- Difficulty for frontend developers
- Manual testing overhead
- Integration issues
- Poor API usability

**Missing Documentation:**
- Request/response schemas
- Authentication requirements
- Error response formats
- Rate limiting information

**Proposed Solution:**
- Generate OpenAPI/Swagger documentation
- Add comprehensive API tests
- Create API usage examples
- Implement API versioning strategy

**Acceptance Criteria:**
- [ ] OpenAPI specification for all endpoints
- [ ] 90%+ API test coverage
- [ ] Interactive API documentation
- [ ] API usage examples and guides

---

## Security Issues

### SEC001: SAML Response Validation Enhancement
**Priority:** High  
**Severity:** Major  
**Component:** Authentication  
**Assigned To:** Security Team  
**Sprint:** Next

**Description:**
SAML response validation could be enhanced to prevent potential security vulnerabilities.

**Security Concerns:**
- XML signature validation
- Replay attack prevention
- Assertion timeout validation
- Certificate expiration handling

**Proposed Solution:**
- Implement comprehensive SAML validation
- Add security logging for authentication events
- Create SAML security monitoring
- Regular security audits

**Acceptance Criteria:**
- [ ] Enhanced SAML validation logic
- [ ] Security audit logging
- [ ] Penetration testing passed
- [ ] Security documentation updated

---

## Infrastructure Issues

### INF001: Application Monitoring and Alerting
**Priority:** Medium  
**Severity:** Minor  
**Component:** Infrastructure  
**Assigned To:** DevOps Team  
**Sprint:** Backlog

**Description:**
Lack of comprehensive application monitoring and alerting for production environment.

**Missing Monitoring:**
- Application performance metrics
- Database connection health
- Session store status
- Error rate tracking
- User activity monitoring

**Proposed Solution:**
- Implement application performance monitoring
- Set up health check endpoints
- Create alerting rules
- Build monitoring dashboards

**Acceptance Criteria:**
- [ ] Application performance dashboard
- [ ] Automated alerting system
- [ ] Health check endpoints
- [ ] Error tracking and notifications

---

This comprehensive set of user stories and issues will help you structure your Azure DevOps project effectively. The user stories follow standard Agile format with clear acceptance criteria and definition of done, while the issues are based on actual technical problems found in your codebase.

