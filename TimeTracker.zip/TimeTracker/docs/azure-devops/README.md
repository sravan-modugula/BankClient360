
# Azure DevOps Integration

This directory contains all Azure DevOps related documentation and templates for the FMB TimeTracker project.

## Contents

- [Azure DevOps Setup Guide](azure-devops-setup.md) - Complete guide for setting up Azure DevOps
- [User Stories](user-stories.md) - Epic and user story templates
- [Issues and Bugs](issues.md) - Issue tracking templates and examples

## Quick Setup

1. Create new Azure DevOps project
2. Import repository
3. Set up build pipelines using provided YAML files
4. Configure work items using provided templates
5. Set up deployment pipelines

## Work Item Structure

### Epics
- Authentication & User Management
- Time Tracking
- Project Management
- Reporting & Analytics
- Organization Management

### User Stories
Each epic contains multiple user stories with:
- Clear acceptance criteria
- Story point estimation
- Definition of done
- Priority classification

### Issues & Bugs
Categorized by:
- Priority (Critical, High, Medium, Low)
- Component (Frontend, Backend, Database, Infrastructure)
- Type (Bug, Technical Debt, Security, Performance)

## Pipeline Configuration

### CI Pipeline
- TypeScript compilation
- Unit tests
- Security scanning
- Build validation

### CD Pipeline
- Environment-specific deployments
- Database migrations
- Health checks
- Rollback procedures

For detailed setup instructions, see [Azure DevOps Setup Guide](azure-devops-setup.md).
