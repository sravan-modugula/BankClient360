

# Azure DevOps Setup Guide for FMB TimeTracker

## Project Structure Recommendations

### 1. Repositories
- **Main Repository:** `fmb-timetracker` (your existing repo)
- **Documentation Repository:** `fmb-timetracker-docs` (separate repo for wiki, guides)
- **Scripts Repository:** `fmb-timetracker-scripts` (deployment and maintenance scripts)

### 2. Work Item Types

#### Custom Work Item Templates

**Epic Template:**
- Title: [Epic Title]
- Description: High-level business capability
- Business Value: [1-100 scale]
- Acceptance Criteria: Epic completion criteria
- Dependencies: Related epics
- Target Release: Release version

**Feature Template:**
- Title: [Feature Title]
- Epic Link: Parent epic
- Story Points: Effort estimation
- Priority: High/Medium/Low
- Component: Frontend/Backend/Database
- Definition of Ready: Checklist before development
- Definition of Done: Checklist for completion

**Bug Template:**
- Title: [Bug Title] - [Component]
- Priority: Critical/High/Medium/Low
- Severity: Blocker/Major/Minor/Trivial
- Environment: Development/Staging/Production
- Steps to Reproduce: Detailed steps
- Expected Behavior: What should happen
- Actual Behavior: What actually happens
- Root Cause: Analysis of the issue
- Impact: Business/user impact
- Workaround: Temporary solution if available

### 3. Azure Boards Configuration

#### Board Columns
**Kanban Board Setup:**
- New
- Approved
- Committed
- In Progress
- Code Review
- Testing
- Done
- Closed

#### Sprint Board Setup:**
- To Do
- In Progress
- Code Review
- Testing
- Done

### 4. Build Pipelines

#### CI Pipeline (azure-pipelines-ci.yml)
```yaml
trigger:
- main
- develop

pool:
  vmImage: 'windows-latest'

stages:
- stage: Build
  jobs:
  - job: BuildAndTest
    steps:
    - task: NodeTool@0
      inputs:
        versionSpec: '20.x'
      displayName: 'Install Node.js'
    
    - script: npm install
      displayName: 'Install dependencies'
    
    - script: npm run check
      displayName: 'TypeScript check'
    
    - script: npm run build
      displayName: 'Build application'
    
    - script: npm run test
      displayName: 'Run tests'
      
    - task: PublishTestResults@2
      inputs:
        testResultsFormat: 'JUnit'
        testResultsFiles: '**/test-results.xml'
      displayName: 'Publish test results'

- stage: SecurityScan
  jobs:
  - job: SecurityAnalysis
    steps:
    - script: node scripts/validate-saml-config.js
      displayName: 'Validate SAML configuration'
    
    - script: npm audit --audit-level high
      displayName: 'Security audit'
```

#### Deployment Pipeline (azure-pipelines-deploy.yml)
```yaml
trigger: none

pool:
  vmImage: 'windows-latest'

parameters:
- name: environment
  displayName: 'Target Environment'
  type: string
  default: 'staging'
  values:
  - staging
  - production

stages:
- stage: Deploy
  jobs:
  - job: DeployApplication
    steps:
    - task: NodeTool@0
      inputs:
        versionSpec: '20.x'
      displayName: 'Install Node.js'
    
    - script: npm install --production
      displayName: 'Install production dependencies'
    
    - script: npm run build
      displayName: 'Build application'
    
    - script: node scripts/fmb-production-check.js
      displayName: 'Production readiness check'
    
    - script: |
        echo "Deploying to ${{ parameters.environment }}"
        # Add deployment commands here
      displayName: 'Deploy application'
```

### 5. Test Plans

#### Test Suite Structure
**Functional Testing:**
- Authentication Tests
  - SAML login flow
  - Role-based access control
  - Session management
- Time Tracking Tests
  - Time entry creation
  - Time entry validation
  - Time entry reporting
- Project Management Tests
  - Project CRUD operations
  - Task management
  - Employee assignments

**Security Testing:**
- Authentication security
- Authorization checks
- Input validation
- Session security
- SAML security

**Performance Testing:**
- Load testing scenarios
- Database performance
- API response times
- Frontend rendering

### 6. Release Management

#### Release Definitions
**Staging Release:**
- Automated deployment from develop branch
- Smoke tests execution
- Stakeholder notification

**Production Release:**
- Manual approval required
- Database migration scripts
- Rollback procedures
- Health checks

#### Deployment Gates
- Automated testing passed
- Security scan completed
- Performance benchmarks met
- Stakeholder approval received

### 7. Reporting and Dashboards

#### Project Dashboard Widgets
- Sprint Burndown
- Velocity Chart
- Bug Trend Analysis
- Test Results Summary
- Build Success Rate
- Code Coverage
- Security Vulnerabilities

#### Custom Reports
- Feature Delivery Report
- Bug Resolution Time
- Sprint Retrospective Data
- Team Capacity Planning
- Technical Debt Tracking

### 8. Branch Policies

#### Main Branch Protection
- Require pull request reviews (2 reviewers)
- Check for linked work items
- Require passing build
- Require up-to-date branches

#### Quality Gates
- Code coverage > 80%
- No critical security vulnerabilities
- All tests passing
- Documentation updated

### 9. Service Connections

#### Required Service Connections
- **Azure Key Vault** (for secrets management)
- **SMTP Server** (for notifications)
- **SQL Server** (for database deployments)
- **Artifact Repository** (for package management)

### 10. Extensions and Integrations

#### Recommended Extensions
- **SonarQube** (code quality analysis)
- **WhiteSource Bolt** (security scanning)
- **Slack/Teams** (notifications)
- **TimeTracker** (work item time tracking)

### 11. Documentation Strategy

#### Wiki Structure
```
Home
├── Architecture
│   ├── System Overview
│   ├── Database Schema
│   └── API Documentation
├── Development
│   ├── Getting Started
│   ├── Coding Standards
│   └── Testing Guidelines
├── Deployment
│   ├── Environment Setup
│   ├── Deployment Guide
│   └── Troubleshooting
└── Operations
    ├── Monitoring
    ├── Maintenance
    └── Support Procedures
```

### 12. Metrics and KPIs

#### Development Metrics
- Velocity (story points per sprint)
- Lead time (idea to production)
- Cycle time (development to done)
- Defect escape rate
- Code coverage percentage

#### Quality Metrics
- Bug resolution time
- Customer satisfaction scores
- System availability
- Performance benchmarks
- Security incident count

This comprehensive Azure DevOps setup will provide you with a robust project management and development environment for your FMB TimeTracker application.

