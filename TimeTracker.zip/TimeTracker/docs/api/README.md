
# API Documentation

FMB TimeTracker REST API reference and usage guide.

## Base URL

```
Development: http://localhost:3000/api
Production: https://your-domain.com/api
```

## Authentication

All API requests require authentication via SAML session cookies.

## Endpoints

### Authentication
- `GET /auth/saml/login` - Initiate SAML login
- `GET /auth/saml/callback` - SAML callback endpoint
- `POST /auth/logout` - Logout user

### Users
- `GET /users` - Get all users (Admin only)
- `GET /users/:id` - Get user by ID
- `PUT /users/:id` - Update user
- `DELETE /users/:id` - Delete user

### Projects
- `GET /projects` - Get user projects
- `POST /projects` - Create project
- `GET /projects/:id` - Get project details
- `PUT /projects/:id` - Update project
- `DELETE /projects/:id` - Delete project

### Time Entries
- `GET /time-entries` - Get user time entries
- `POST /time-entries` - Create time entry
- `GET /time-entries/:id` - Get time entry
- `PUT /time-entries/:id` - Update time entry
- `DELETE /time-entries/:id` - Delete time entry

### Tasks
- `GET /tasks` - Get tasks
- `POST /tasks` - Create task
- `GET /tasks/:id` - Get task
- `PUT /tasks/:id` - Update task
- `DELETE /tasks/:id` - Delete task

### Reports
- `GET /reports/time/:projectId` - Get time reports
- `GET /reports/project/:projectId` - Get project reports

## Error Handling

All endpoints return consistent error responses:

```json
{
  "message": "Error description",
  "code": "ERROR_CODE",
  "details": {}
}
```

## Rate Limiting

API requests are limited to prevent abuse. Limits vary by endpoint and user role.

For detailed endpoint documentation, see the individual endpoint files in this directory.
