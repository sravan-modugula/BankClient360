
# FMB TimeTracker - On-Premises Edition

## Overview

FMB TimeTracker is a comprehensive time tracking and project management solution designed specifically for on-premises deployment. Built with modern web technologies, it provides secure SAML authentication, role-based access control, and enterprise-grade features.

## Features

- **SAML Authentication**: Secure integration with RSA Identity Provider
- **Role-Based Access Control**: Admin, Manager, Project Manager, Employee, and Viewer roles
- **Time Tracking**: Flexible time entry with validation and conflict detection
- **Project Management**: Create and manage projects with team assignments
- **Task Management**: Organize work with project-based tasks
- **Reporting**: Comprehensive time and project reports
- **Dashboard**: Real-time insights and analytics
- **Department Management**: Organizational structure support

## Technology Stack

- **Frontend**: React 18, TypeScript, Vite, TailwindCSS, shadcn/ui
- **Backend**: Node.js, Express, TypeScript
- **Database**: Microsoft SQL Server
- **Authentication**: SAML 2.0 with RSA Identity Provider
- **Session Management**: SQL Server-based sessions

## Quick Start

1. **Prerequisites**: Node.js 20+, Microsoft SQL Server
2. **Installation**: `npm install`
3. **Configuration**: Copy `.env.example` to `.env` and configure
4. **Database Setup**: Run migration scripts
5. **Start Development**: `npm run dev`

For detailed setup instructions, see [Installation Guide](installation/README.md).

## Documentation

- [Installation Guide](installation/)
- [Configuration](configuration/)
- [API Documentation](api/)
- [User Guide](user-guide/)
- [Development Guide](development/)
- [Deployment Guide](deployment/)
- [Troubleshooting](troubleshooting/)

## Support

For support and issues, refer to the troubleshooting guide or contact your system administrator.
