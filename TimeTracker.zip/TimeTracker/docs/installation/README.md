
# Installation Guide

This guide covers the complete installation process for FMB TimeTracker on-premises deployment.

## Prerequisites

### System Requirements
- Windows Server 2019/2022 or Linux
- Node.js 20.x or higher
- Microsoft SQL Server 2019 or higher
- IIS (for Windows deployment)
- 4GB RAM minimum
- 10GB disk space

### Network Requirements
- HTTPS access to RSA Identity Provider
- Database connectivity
- Port 3000 (or configured port) available

## Installation Steps

### 1. Database Setup

Run the SQL scripts in order:
1. `migrations/0000_salty_iron_man.sql`
2. `migrations/0001_hot_kabuki.sql`
3. `migrations/0002_fix_column_names.sql`
4. `fmb-onprem/scripts/fmb-complete-setup.sql`

### 2. Application Installation

```bash
# Clone repository
git clone <repository-url>
cd fmb-timetracker

# Install dependencies
npm install

# Build application
npm run build
```

### 3. Configuration

1. Copy environment files:
   ```bash
   cp .env.example .env
   cp fmb-onprem/.env.fmb-onprem.example fmb-onprem/.env.fmb-onprem
   ```

2. Configure database connection in `.env`:
   ```
   DB_SERVER=your-sql-server
   DB_DATABASE=timetracker_dev
   DB_USERNAME=your-username
   DB_PASSWORD=your-password
   ```

3. Configure SAML settings in `fmb-onprem/.env.fmb-onprem`

### 4. SAML Certificate Setup

Place your SAML certificate as `saml_cert.pem` in the root directory.

### 5. Start Application

```bash
npm run dev
```

For production deployment, see [Windows Installation Guide](windows-installation.md).

## Next Steps

- [Configuration Guide](../configuration/README.md)
- [User Management](../user-guide/user-management.md)
- [Troubleshooting](../troubleshooting/README.md)
