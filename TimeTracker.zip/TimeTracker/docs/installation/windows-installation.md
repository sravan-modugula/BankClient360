
# Windows Installation Guide

Complete guide for installing FMB TimeTracker on Windows Server.

## Prerequisites

- Windows Server 2019/2022
- Internet Information Services (IIS) with ASP.NET Core Hosting Bundle
- Node.js 20.x LTS
- Microsoft SQL Server 2019+
- PowerShell 5.1 or PowerShell Core

## Installation Process

### 1. Server Preparation

```powershell
# Enable IIS and required features
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole, IIS-WebServer, IIS-CommonHttpFeatures, IIS-HttpErrors, IIS-HttpRedirect, IIS-ApplicationDevelopment, IIS-NetFxExtensibility45, IIS-HealthAndDiagnostics, IIS-HttpLogging, IIS-Security, IIS-RequestFiltering, IIS-Performance, IIS-WebServerManagementTools, IIS-ManagementConsole, IIS-IIS6ManagementCompatibility, IIS-Metabase

# Install Node.js (Download from https://nodejs.org)
# Install SQL Server (if not already installed)
```

### 2. Application Setup

Run the automated installation script:

```powershell
# Run as Administrator
.\fmb-onprem\scripts\fmb-install.ps1 -InstallPath "C:\fmb-timetracker"
```

This script will:
- Create application directory
- Install Node.js dependencies
- Configure IIS application pool and site
- Set up SSL certificate
- Configure Windows services
- Create database schema

### 3. Manual Configuration

If you prefer manual setup:

```powershell
# 1. Create directory and copy files
New-Item -ItemType Directory -Path "C:\fmb-timetracker"
Copy-Item -Recurse -Path ".\*" -Destination "C:\fmb-timetracker"

# 2. Install dependencies
Set-Location "C:\fmb-timetracker"
npm install --production

# 3. Build application
npm run build

# 4. Configure IIS
.\fmb-onprem\scripts\fmb-iis-config.ps1
```

### 4. Database Configuration

```powershell
# Run database setup
sqlcmd -S "YourSQLServer" -d "master" -i ".\fmb-onprem\scripts\fmb-complete-setup.sql"
```

### 5. Service Configuration

Configure Windows Service using PM2:

```powershell
# Install PM2 globally
npm install -g pm2
npm install -g pm2-windows-service

# Configure service
pm2 start ecosystem.config.cjs --env production
pm2 save
pm2-service-install
pm2-service-start
```

### 6. SSL Configuration

```powershell
# Configure SSL certificate in IIS
# This is handled by fmb-iis-config.ps1 script
```

## Post-Installation

### Validation

Run the validation script:
```powershell
.\fmb-onprem\scripts\fmb-final-validation.ps1
```

### Service Management

```powershell
# Start services
Start-Service "PM2"
Start-WebAppPool "FMBTimeTracker"

# Check status
Get-Service "PM2"
Get-WebAppPool "FMBTimeTracker"
```

## Troubleshooting

Common issues and solutions:

### Application Won't Start
- Check Node.js version: `node --version`
- Verify dependencies: `npm list`
- Check logs: `C:\fmb-timetracker\logs\`

### Database Connection Issues
- Verify SQL Server connectivity
- Check connection string in `.env`
- Ensure SQL Server authentication is enabled

### SAML Authentication Issues
- Verify certificate path and permissions
- Check RSA IdP configuration
- Review SAML logs in application

## Security Considerations

1. **File Permissions**: Ensure IIS_IUSRS has appropriate access
2. **Firewall**: Configure Windows Firewall for required ports
3. **SSL**: Use valid SSL certificates for production
4. **Database**: Use dedicated SQL Server account with minimal privileges

## Maintenance

### Updates
```powershell
# Stop services
pm2 stop all
Stop-WebAppPool "FMBTimeTracker"

# Update application
git pull origin main
npm install
npm run build

# Start services
Start-WebAppPool "FMBTimeTracker"
pm2 start all
```

### Backup
- Regular database backups
- Application files backup
- Configuration files backup

For more details, see the [Deployment Guide](../deployment/README.md).
