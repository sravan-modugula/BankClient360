
# FMB TimeTracker - Production Deployment Guide
## Two-VM Setup with Load Balancer and IIS

This guide covers the production deployment of FMB TimeTracker using two Windows Server VMs with IIS load balancing for high availability and scalability.

## Architecture Overview

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Users/Web     │◄──►│  Load Balancer   │◄──►│   VM Server 1   │
│   Browser       │    │  (IIS ARR)       │    │ timetracker-vm1 │
└─────────────────┘    │  timetracker-lb  │    └─────────────────┘
                       └──────────────────┘              │
                                 │                       │
                                 │              ┌─────────────────┐
                                 └─────────────►│   VM Server 2   │
                                                │ timetracker-vm2 │
                                                └─────────────────┘
                                                          │
                       ┌──────────────────┐              │
                       │   SQL Server     │◄─────────────┘
                       │  HUB-SQL1TST-LIS │
                       └──────────────────┘
                                 │
                       ┌──────────────────┐
                       │   SAML IdP       │
                       │   (RSA/ADFS)     │
                       └──────────────────┘
```

### Server Configuration

- **Load Balancer**: `timetracker-lb.fmb.com` (Windows Server 2022 with IIS ARR)
- **Application Server 1**: `timetracker-vm1.fmb.com` (Windows Server 2022)
- **Application Server 2**: `timetracker-vm2.fmb.com` (Windows Server 2022)
- **Database**: `HUB-SQL1TST-LIS` (MS SQL Server - shared)
- **Public Domain**: `https://timetracker.fmb.com`

## Prerequisites

### Load Balancer Server (timetracker-lb)
- Windows Server 2022
- IIS 10.0+ with Application Request Routing (ARR)
- URL Rewrite Module
- Valid SSL certificate for timetracker.fmb.com
- 4GB RAM minimum
- Network access to both application servers

### Application Servers (timetracker-vm1, timetracker-vm2)
- Windows Server 2022
- Node.js 20.x LTS
- IIS 10.0+ (for reverse proxy)
- PowerShell 5.1 or higher
- 8GB RAM minimum per server
- Network access to SQL Server and Load Balancer

### Database Server
- MS SQL Server 2019+ (existing HUB-SQL1TST-LIS)
- Network access from both application servers
- Session store database configured

## Installation Steps

### Phase 1: Database Preparation

Run on the SQL Server (HUB-SQL1TST-LIS):

```sql
-- Create production database and session store
-- Run: fmb-onprem/scripts/fmb-complete-setup.sql
-- This creates all tables, indexes, and sample data

-- Create additional indexes for production load
CREATE INDEX IX_Sessions_SessionId_Active ON Sessions (sessionId) WHERE active = 1;
CREATE INDEX IX_TimeEntries_UserDate ON TimeEntries (userId, date);
CREATE INDEX IX_Projects_Active ON Projects (isActive);
```

### Phase 2: Application Server Setup (Run on Both VMs)

#### 2.1 Prerequisites Installation

```powershell
# Install Node.js, Git, and PM2 on both servers
choco install nodejs git -y
npm install -g pm2 pm2-windows-service

# Create application directory
New-Item -ItemType Directory -Path "C:\fmb-timetracker" -Force
```

#### 2.2 Application Deployment

```powershell
# Clone and setup application (run on both servers)
cd C:\
git clone <repository-url> fmb-timetracker-source
cd fmb-timetracker-source

# Copy FMB production files
Copy-Item -Recurse -Path ".\*" -Destination "C:\fmb-timetracker"
```

#### 2.3 Environment Configuration

Create `C:\fmb-timetracker\.env` on both servers:

```env
# FMB Production Configuration
FMB_DEPLOYMENT=onprem
NODE_ENV=production

# Database Configuration (Shared SQL Server)
FMB_DB_SERVER=HUB-SQL1TST-LIS
FMB_DB_NAME=timetracker_production
FMB_DB_USER=timetracker_prod
FMB_DB_PASSWORD=your_secure_production_password
FMB_DB_PORT=1433
FMB_DB_ENCRYPT=true
FMB_DB_TRUST_CERT=true

# Load Balancer Configuration
FMB_LOAD_BALANCER=true
FMB_SERVER_ID=vm1  # Use 'vm2' for second server

# SAML Configuration (Production RSA)
FMB_SAML_ENTITY_ID=https://timetracker.fmb.com
FMB_SAML_SSO_URL=https://rsa-prod.fmb.com/saml/sso
FMB_SAML_ACS_URL=https://timetracker.fmb.com/saml/acs
FMB_SAML_CERTIFICATE=-----BEGIN CERTIFICATE-----\nYOUR_PRODUCTION_SAML_CERT\n-----END CERTIFICATE-----

# Application Configuration
PORT=3000
HOST=0.0.0.0
FMB_SESSION_SECRET=your_super_secure_production_session_secret_32chars

# Health Check Configuration
FMB_HEALTH_CHECK_PORT=3001
FMB_HEALTH_CHECK_ENABLED=true

# Logging Configuration
FMB_LOG_LEVEL=info
FMB_LOG_FILE=C:\fmb-timetracker\logs\production.log
```

#### 2.4 Application Build and Installation

```powershell
# Build application on both servers
cd C:\fmb-timetracker
npm install --production
npm run build

# Create PM2 ecosystem configuration
```

Create `C:\fmb-timetracker\ecosystem.production.cjs`:

```javascript
module.exports = {
  apps: [{
    name: 'fmb-timetracker-prod',
    script: 'dist/index.js',
    cwd: 'C:\\fmb-timetracker',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      FMB_DEPLOYMENT: 'onprem',
      FMB_LOAD_BALANCER: 'true'
    },
    instances: 2,
    exec_mode: 'cluster',
    watch: false,
    max_memory_restart: '4G',
    log_file: 'logs\\production.log',
    out_file: 'logs\\out.log',
    error_file: 'logs\\error.log',
    time: true,
    merge_logs: true,
    windows_hide: true,
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
```

#### 2.5 IIS Reverse Proxy Configuration (Both Servers)

```powershell
# Configure IIS reverse proxy on both application servers
.\fmb-onprem\scripts\fmb-iis-config.ps1 -SiteName "timetracker-app" -ApplicationPool "FMBTimeTrackerProd" -NodePort 3000

# Configure health check endpoint
```

Create health check configuration for each server:

`C:\inetpub\wwwroot\timetracker-app\health.html`:
```html
<!DOCTYPE html>
<html>
<head>
    <title>FMB TimeTracker Health Check</title>
</head>
<body>
    <h1>Server Status: OK</h1>
    <p>Server: vm1</p> <!-- Change to vm2 for second server -->
    <p>Timestamp: <span id="timestamp"></span></p>
    <script>
        document.getElementById('timestamp').textContent = new Date().toISOString();
    </script>
</body>
</html>
```

### Phase 3: Load Balancer Configuration

#### 3.1 Load Balancer Server Setup

```powershell
# Install IIS and ARR on load balancer server
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole, IIS-WebServer, IIS-CommonHttpFeatures, IIS-ApplicationDevelopment -All

# Install URL Rewrite Module
$urlRewriteUrl = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"
$tempPath = "$env:TEMP\urlrewrite.msi"
Invoke-WebRequest -Uri $urlRewriteUrl -OutFile $tempPath
Start-Process msiexec.exe -Wait -ArgumentList "/i `"$tempPath`" /quiet"

# Install Application Request Routing (ARR)
$arrUrl = "https://download.microsoft.com/download/E/9/8/E9849D6A-020E-47E4-9FD0-A023E99B54EB/requestRouter_amd64.msi"
$arrTempPath = "$env:TEMP\arr.msi"
Invoke-WebRequest -Uri $arrUrl -OutFile $arrTempPath
Start-Process msiexec.exe -Wait -ArgumentList "/i `"$arrTempPath`" /quiet"

# Enable ARR proxy functionality
Import-Module WebAdministration
Set-WebConfigurationProperty -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/proxy" -Name "enabled" -Value "True"
```

#### 3.2 Create Load Balancer Site

```powershell
# Create application pool for load balancer
New-WebAppPool -Name "FMBTimeTrackerLB"
Set-ItemProperty -Path "IIS:\AppPools\FMBTimeTrackerLB" -Name processModel.identityType -Value ApplicationPoolIdentity

# Create website
$lbPath = "C:\inetpub\wwwroot\timetracker.fmb.com"
New-Item -ItemType Directory -Path $lbPath -Force

New-Website -Name "timetracker.fmb.com" -Port 80 -PhysicalPath $lbPath -ApplicationPool "FMBTimeTrackerLB"
New-WebBinding -Name "timetracker.fmb.com" -Protocol https -Port 443
```

#### 3.3 Configure Server Farm

```powershell
# Create server farm configuration
```

Create `C:\inetpub\wwwroot\timetracker.fmb.com\web.config`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="Force HTTPS" stopProcessing="true">
          <match url="(.*)" />
          <conditions>
            <add input="{HTTPS}" pattern="off" ignoreCase="true" />
          </conditions>
          <action type="Redirect" url="https://{HTTP_HOST}/{R:1}" redirectType="Permanent" />
        </rule>
        
        <rule name="Health Check VM1" stopProcessing="true">
          <match url="^health/vm1$" />
          <action type="Rewrite" url="http://timetracker-vm1.fmb.com/health" />
        </rule>
        
        <rule name="Health Check VM2" stopProcessing="true">
          <match url="^health/vm2$" />
          <action type="Rewrite" url="http://timetracker-vm2.fmb.com/health" />
        </rule>
        
        <rule name="Load Balance to Server Farm" stopProcessing="true">
          <match url="(.*)" />
          <conditions>
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="http://FMBTimeTrackerFarm/{R:1}" />
          <serverVariables>
            <set name="HTTP_X_FORWARDED_PROTO" value="{HTTPS_ON:https:http}" />
            <set name="HTTP_X_FORWARDED_FOR" value="{REMOTE_ADDR}" />
            <set name="HTTP_X_FORWARDED_HOST" value="{HTTP_HOST}" />
            <set name="HTTP_X_ORIGINAL_URL" value="{REQUEST_URI}" />
          </serverVariables>
        </rule>
      </rules>
    </rewrite>
    
    <httpErrors errorMode="Detailed" />
    
    <httpProtocol>
      <customHeaders>
        <add name="Strict-Transport-Security" value="max-age=31536000; includeSubDomains" />
        <add name="X-Content-Type-Options" value="nosniff" />
        <add name="X-Frame-Options" value="DENY" />
        <add name="X-XSS-Protection" value="1; mode=block" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
```

#### 3.4 Configure Application Request Routing

```powershell
# Configure server farm through IIS Manager or PowerShell
# Create server farm named "FMBTimeTrackerFarm" with these servers:
# - timetracker-vm1.fmb.com (port 80)
# - timetracker-vm2.fmb.com (port 80)

# Set load balancing algorithm to "Least current requests"
# Enable health monitoring on /health endpoint
```

### Phase 4: SSL Certificate Installation

```powershell
# Install SSL certificate on load balancer
Import-PfxCertificate -FilePath "C:\certs\timetracker.fmb.com.pfx" -CertStoreLocation Cert:\LocalMachine\My -Password (Read-Host -AsSecureString)

# Bind certificate to HTTPS site
$cert = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object {$_.Subject -like "*timetracker.fmb.com*"}
New-WebBinding -Name "timetracker.fmb.com" -Protocol https -Port 443 -SslFlags 1
```

### Phase 5: Application Startup

#### 5.1 Start Application Servers

```powershell
# On both VM servers (vm1 and vm2)
cd C:\fmb-timetracker

# Start PM2 applications
pm2 start ecosystem.production.cjs
pm2 save

# Install PM2 as Windows service
pm2-service-install -n "FMBTimeTrackerProd"
pm2-service-start

# Start IIS
Start-WebAppPool "FMBTimeTrackerProd"
Start-Website "timetracker-app"
```

#### 5.2 Start Load Balancer

```powershell
# On load balancer server
Start-WebAppPool "FMBTimeTrackerLB"
Start-Website "timetracker.fmb.com"
```

### Phase 6: Validation and Testing

#### 6.1 Health Checks

```powershell
# Test individual servers
Invoke-WebRequest -Uri "http://timetracker-vm1.fmb.com/health" -UseBasicParsing
Invoke-WebRequest -Uri "http://timetracker-vm2.fmb.com/health" -UseBasicParsing

# Test load balancer health checks
Invoke-WebRequest -Uri "https://timetracker.fmb.com/health/vm1" -UseBasicParsing
Invoke-WebRequest -Uri "https://timetracker.fmb.com/health/vm2" -UseBasicParsing

# Test main application
Invoke-WebRequest -Uri "https://timetracker.fmb.com" -UseBasicParsing
```

#### 6.2 Load Testing

```powershell
# Simple load test script
for ($i = 1; $i -le 10; $i++) {
    Start-Job -ScriptBlock {
        for ($j = 1; $j -le 5; $j++) {
            Invoke-WebRequest -Uri "https://timetracker.fmb.com/api/health" -UseBasicParsing
            Start-Sleep -Seconds 1
        }
    }
}

# Wait for jobs to complete
Get-Job | Wait-Job
Get-Job | Receive-Job
Get-Job | Remove-Job
```

## Production Monitoring

### 6.3 Performance Monitoring

```powershell
# Monitor application servers
pm2 monit

# Check IIS logs on load balancer
Get-Content "C:\inetpub\logs\LogFiles\W3SVC1\*.log" -Tail 20 -Wait

# Monitor server farm health in IIS Manager
```

### 6.4 Database Session Monitoring

```sql
-- Monitor active sessions
SELECT 
    COUNT(*) as ActiveSessions,
    AVG(DATEDIFF(minute, lastActivity, GETUTCDATE())) as AvgInactiveMinutes
FROM Sessions 
WHERE active = 1;

-- Check session distribution
SELECT 
    serverId,
    COUNT(*) as SessionCount
FROM Sessions 
WHERE active = 1
GROUP BY serverId;
```

## Maintenance and Updates

### Deployment Updates

```powershell
# Zero-downtime deployment script
# 1. Update VM1 while VM2 serves traffic
# 2. Test VM1
# 3. Update VM2 while VM1 serves traffic
# 4. Restore both servers to load balancer

# Remove VM1 from load balancer (manual in IIS Manager)
# Update VM1
cd C:\fmb-timetracker
git pull origin main
npm install --production
npm run build
pm2 restart ecosystem.production.cjs

# Test VM1
Invoke-WebRequest -Uri "http://timetracker-vm1.fmb.com/health" -UseBasicParsing

# Add VM1 back to load balancer
# Repeat for VM2
```

### Backup Strategy

```powershell
# Application backup
robocopy "C:\fmb-timetracker" "D:\backups\fmb-timetracker-$(Get-Date -Format 'yyyyMMdd')" /MIR

# Database backup (run on SQL Server)
BACKUP DATABASE timetracker_production 
TO DISK = 'D:\backups\timetracker_production_$(Get-Date -Format "yyyyMMdd").bak'
```

## Security Considerations

1. **Network Security**: Configure Windows Firewall on all servers
2. **SSL/TLS**: Use valid certificates and TLS 1.2+
3. **Database Security**: Use dedicated service accounts with minimal privileges
4. **Session Security**: Regular session cleanup and monitoring
5. **Access Control**: Implement proper file system permissions
6. **Monitoring**: Set up alerts for failed health checks and high error rates

## Troubleshooting

### Common Issues

1. **Load Balancer Not Routing**: Check ARR configuration and server farm health
2. **Session Affinity Issues**: Ensure proper session store configuration
3. **SSL Certificate Problems**: Verify certificate installation and binding
4. **Database Connection Issues**: Check connection strings and firewall rules
5. **Performance Issues**: Monitor CPU, memory, and database performance

### Log Locations

- **Application Logs**: `C:\fmb-timetracker\logs\`
- **IIS Logs**: `C:\inetpub\logs\LogFiles\`
- **Windows Event Logs**: Application and System logs
- **PM2 Logs**: `pm2 logs`

For additional support, refer to the [Troubleshooting Guide](../troubleshooting/README.md).
