
# Troubleshooting Guide

Common issues and their solutions for FMB TimeTracker.

## Application Startup Issues

### SAML Certificate Path Resolution Failure

**Error:**
```
SAML certificate file not found: /home/runner/workspace/C:/fmb-timetracker/saml_cert.pem
```

**Solution:**
1. Ensure `saml_cert.pem` is in the project root
2. Check file permissions
3. Verify certificate format

### Database Connection Issues

**Error:** 
```
Failed to connect to FMB database
```

**Solutions:**
1. Verify SQL Server is running
2. Check connection string in `.env`
3. Ensure database exists and is accessible
4. Verify firewall settings

## Runtime Issues

### Session Store Connection Failures

**Error:**
```
SESSION-Failed to connect to session store
```

**Solutions:**
1. Check database connection pool settings
2. Verify session table exists
3. Monitor database performance
4. Review session cleanup processes

### Duplicate Method Warnings

**Error:**
```
Duplicate member "executeQuery" in class body
```

**Solution:**
This has been resolved in the latest version. Update your codebase.

## Authentication Issues

### SAML Login Failures

**Symptoms:**
- Users cannot log in
- Redirect loops
- Authentication errors

**Solutions:**
1. Verify RSA IdP configuration
2. Check SAML certificate validity
3. Review SAML metadata
4. Validate entity IDs match

## Performance Issues

### Slow Database Queries

**Symptoms:**
- Long page load times
- Timeout errors
- High CPU usage

**Solutions:**
1. Review database indexes
2. Optimize query structure
3. Implement query caching
4. Monitor query performance

## Getting Help

1. Check application logs
2. Review error messages carefully
3. Verify configuration settings
4. Contact system administrator

For specific error codes and detailed solutions, see the [Error Reference](error-reference.md).
