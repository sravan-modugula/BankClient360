
# Configuration Guide

Complete configuration reference for FMB TimeTracker.

## Environment Variables

### Database Configuration

```bash
# Database Connection
DB_SERVER=your-sql-server
DB_DATABASE=timetracker_dev
DB_USERNAME=your-username
DB_PASSWORD=your-password
DB_PORT=1433
DB_ENCRYPT=true
DB_TRUST_SERVER_CERTIFICATE=false
```

### Application Settings

```bash
# Server Configuration
PORT=3000
NODE_ENV=development
SESSION_SECRET=your-session-secret

# Logging
LOG_LEVEL=info
LOG_FORMAT=combined
```

### SAML Configuration

Located in `fmb-onprem/.env.fmb-onprem`:

```bash
# SAML Settings
SAML_ENTITY_ID=https://your-app.com
SAML_ASSERTION_CONSUMER_SERVICE_URL=https://your-app.com/auth/saml/callback
SAML_SINGLE_LOGOUT_SERVICE_URL=https://your-app.com/auth/logout
SAML_IDP_ENTRY_POINT=https://your-idp.com/sso
SAML_IDP_ISSUER=https://your-idp.com
SAML_CERT_PATH=./saml_cert.pem

# Identity Provider
FMB_RSA_IDP_URL=https://your-rsa-idp.com
FMB_RSA_ENTITY_ID=your-entity-id
```

## Database Schema

The application uses Microsoft SQL Server with the following main tables:

- `users` - User accounts and profiles
- `employees` - Employee information
- `projects` - Project definitions
- `tasks` - Task management
- `time_entries` - Time tracking data
- `sessions` - User session storage

## SAML Certificate

Place your SAML certificate as `saml_cert.pem` in the project root. The certificate should be in PEM format.

## Session Configuration

Sessions are stored in SQL Server. Configure session settings:

```javascript
// Session timeout (milliseconds)
SESSION_TIMEOUT=3600000  // 1 hour

// Session cleanup interval
SESSION_CLEANUP_INTERVAL=300000  // 5 minutes
```

## Role-Based Access Control

Configure user roles and permissions:

- **Admin**: Full system access
- **Manager**: Department and team management
- **Project Manager**: Project and task management
- **Employee**: Time entry and personal data
- **Viewer**: Read-only access

## Security Settings

### HTTPS Configuration

For production deployment:
- Use valid SSL certificates
- Configure secure headers
- Enable HSTS
- Implement CSP policies

### Password Policies

Configure through your identity provider (RSA).

## Performance Tuning

### Database Connection Pool

```javascript
// Connection pool settings
DB_POOL_MIN=2
DB_POOL_MAX=10
DB_POOL_IDLE_TIMEOUT=30000
```

### Caching

Configure application-level caching for improved performance.

## Monitoring and Logging

Configure logging and monitoring:

```bash
# Log file locations
LOG_FILE_PATH=./logs/app.log
ERROR_LOG_PATH=./logs/error.log

# Monitoring endpoints
HEALTH_CHECK_ENDPOINT=/health
METRICS_ENDPOINT=/metrics
```

For deployment-specific configurations, see the [Deployment Guide](../deployment/README.md).
