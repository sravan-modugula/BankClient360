
# FMB TimeTracker - Enterprise Wiki

## Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Architecture](#architecture)
4. [Installation Guide](#installation-guide)
5. [Configuration](#configuration)
6. [User Guide](#user-guide)
7. [Administrative Guide](#administrative-guide)
8. [Troubleshooting](#troubleshooting)
9. [Development](#development)
10. [Security](#security)
11. [Maintenance](#maintenance)
12. [API Reference](#api-reference)

---

## Overview

FMB TimeTracker is an enterprise-grade time tracking and project management application designed exclusively for First Midwest Bank's on-premises infrastructure. Built with modern web technologies and integrated with FMB's existing authentication and database systems.

### Key Features

- **Time Tracking**: Manual time entry, project-based tracking, task assignment
- **Project Management**: Project creation, task management, employee assignment
- **Organizational Structure**: Multi-level organization, department, and employee management
- **Enterprise Security**: SAML 2.0 authentication with RSA Identity Provider
- **Role-Based Access Control**: Admin, Manager, Project Manager, Employee, Viewer roles
- **Comprehensive Reporting**: Time reports, project analytics, department summaries
- **Real-time Dashboard**: Statistics, recent activity, project breakdowns

### Technology Stack

- **Frontend**: React 18, TypeScript, Material-UI, Vite
- **Backend**: Node.js, Express, TypeScript
- **Database**: MS SQL Server with Tedious driver
- **Authentication**: Passport-SAML strategy with RSA Identity Provider
- **Session Management**: Custom MS SQL session store
- **Build Tools**: Vite, ESBuild, TypeScript compiler

---

## Quick Start

### Prerequisites
- Windows Server 2022
- Node.js 20.x or higher
- MS SQL Server access (HUB-SQL1TST-LIS)
- IIS with URL Rewrite Module
- SAML certificate from RSA Identity Provider

### 5-Minute Setup

```powershell
# 1. Clone and install
git clone <repository-url>
cd fmb-timetracker
.\fmb-onprem\scripts\fmb-install.ps1

# 2. Configure environment
copy fmb-onprem\.env.fmb-onprem .env
# Edit .env with your settings

# 3. Setup database
sqlcmd -S HUB-SQL1TST-LIS -d timetracker -U timetracker -i fmb-onprem\scripts\fmb-complete-setup.sql

# 4. Build and start
npm run build
npx pm2 start ecosystem.config.cjs
```

### Access Points
- **Application**: https://timetracker.fmb.com
- **Health Check**: https://timetracker.fmb.com/api/health
- **SAML Login**: https://timetracker.fmb.com/saml/login

---

## Architecture

### System Components

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   IIS Proxy     │    │  Node.js App    │    │  MS SQL Server  │
│   (Port 443)    │◄──►│   (Port 3000)   │◄──►│ HUB-SQL1TST-LIS│
└─────────────────┘    └─────────────────┘    └─────────────────┘
         ▲                       ▲                       ▲
         │                       │                       │
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Users/HTTPS   │    │  RSA Identity   │    │  Session Store  │
│                 │    │    Provider     │    │   (MS SQL)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Data Flow

1. **Authentication**: SAML 2.0 → RSA Identity Provider → Application
2. **Session Management**: MS SQL Server session store
3. **Data Storage**: MS SQL Server with encrypted connections
4. **Web Traffic**: HTTPS → IIS → Node.js Application

### Directory Structure

```
fmb-timetracker/
├── client/                 # React frontend application
├── server/                 # Express backend application
├── fmb-onprem/            # FMB-specific configurations
│   ├── auth/              # SAML authentication
│   ├── config/            # Environment configuration
│   ├── scripts/           # Deployment and setup scripts
│   ├── storage/           # MS SQL storage layer
│   └── utils/             # Utility functions
├── shared/                # Shared types and utilities
└── dist/                  # Built application files
```

---

## Installation Guide

### Detailed Installation

#### Step 1: System Prerequisites

```powershell
# Install required software
choco install git nodejs pm2 -y

# Verify installations
node --version    # Should be 20.x+
npm --version     # Should be 10.x+
git --version     # Should be 2.x+
```

#### Step 2: Database Setup

Execute the complete database setup script:

```sql
-- File: fmb-onprem/scripts/fmb-complete-setup.sql
-- This creates all tables, indexes, constraints, and sample data
```

Key tables created:
- `users` - User authentication and profiles
- `sessions` - Express session storage
- `organizations` - Organizational structure
- `departments` - Department management
- `employees` - Employee profiles
- `projects` - Project definitions
- `tasks` - Task management
- `time_entries` - Time tracking records
- `project_employees` - Project assignments

#### Step 3: Application Installation

```powershell
# Run the automated installation script
.\fmb-onprem\scripts\fmb-install.ps1 -InstallPath "C:\fmb-timetracker"

# This script will:
# - Create application directory
# - Install Node.js dependencies
# - Configure PM2 process manager
# - Set up Windows service
# - Configure IIS reverse proxy
```

#### Step 4: Environment Configuration

Edit `.env` file with FMB-specific settings:

```env
# Core Configuration
FMB_DEPLOYMENT=onprem
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Database Configuration
FMB_DB_SERVER=HUB-SQL1TST-LIS
FMB_DB_NAME=timetracker
FMB_DB_USER=timetracker
FMB_DB_PASSWORD=your_secure_password
FMB_DB_PORT=1433
FMB_DB_ENCRYPT=true
FMB_DB_TRUST_SERVER_CERTIFICATE=true

# SAML Configuration
FMB_SAML_ENTITY_ID=https://timetracker.fmb.com
FMB_SAML_SSO_URL=https://rsa.fmb.com/saml/sso
FMB_SAML_ACS_URL=https://timetracker.fmb.com/saml/acs
FMB_SAML_CERTIFICATE=your_saml_certificate_content

# Security
FMB_SESSION_SECRET=your-super-secure-session-secret-32-plus-characters
```

#### Step 5: Build and Deploy

```powershell
# Install dependencies
npm install

# Build application
npm run build

# Start with PM2
npx pm2 start ecosystem.config.cjs
npx pm2 save
```

---

## Configuration

### Environment Variables Reference

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `FMB_DEPLOYMENT` | Deployment type | Yes | `onprem` |
| `NODE_ENV` | Environment mode | Yes | `production` |
| `FMB_DB_SERVER` | SQL Server hostname | Yes | - |
| `FMB_DB_NAME` | Database name | Yes | `timetracker` |
| `FMB_DB_USER` | Database username | Yes | - |
| `FMB_DB_PASSWORD` | Database password | Yes | - |
| `FMB_SAML_ENTITY_ID` | SAML entity identifier | Yes | - |
| `FMB_SAML_SSO_URL` | SAML SSO endpoint | Yes | - |
| `FMB_SAML_ACS_URL` | SAML ACS callback URL | Yes | - |
| `FMB_SAML_CERTIFICATE` | SAML certificate content | Yes | - |
| `FMB_SESSION_SECRET` | Session encryption key | Yes | - |
| `PORT` | Application port | No | `3000` |
| `HOST` | Bind address | No | `0.0.0.0` |

### SAML Configuration

#### RSA Identity Provider Setup

1. **Entity ID**: `https://timetracker.fmb.com`
2. **ACS URL**: `https://timetracker.fmb.com/saml/acs`
3. **Binding**: HTTP-POST
4. **Name ID Format**: Persistent
5. **Attributes Required**:
   - `email` - User email address
   - `firstName` - User first name
   - `lastName` - User last name
   - `role` - User role (admin, manager, project_manager, employee, viewer)

#### Certificate Management

```powershell
# Validate certificate
.\fmb-onprem\scripts\validate-saml-cert.ps1

# Check certificate expiration
openssl x509 -in saml_cert.pem -text -noout | grep "Not After"
```

### IIS Configuration

The application uses IIS as a reverse proxy:

```xml
<!-- IIS web.config for reverse proxy -->
<system.webServer>
  <rewrite>
    <rules>
      <rule name="ReverseProxyInboundRule1" stopProcessing="true">
        <match url="(.*)" />
        <action type="Rewrite" url="http://localhost:3000/{R:1}" />
      </rule>
    </rules>
  </rewrite>
</system.webServer>
```

---

## User Guide

### Getting Started

#### First Login

1. Navigate to `https://timetracker.fmb.com`
2. Click "Login with SAML"
3. Authenticate through RSA Identity Provider
4. Complete profile setup if prompted

#### Dashboard Overview

The dashboard provides:
- **Quick Stats**: Total hours, projects, tasks
- **Recent Activity**: Latest time entries and updates
- **Project Breakdown**: Hours by project (pie chart)
- **Department Hours**: Team time tracking summary

### Time Tracking

#### Creating Time Entries

1. **Navigate**: Go to "Time Entry" page
2. **Select Project**: Choose from assigned projects
3. **Select Task**: Pick specific task (optional)
4. **Enter Details**:
   - Date (defaults to today)
   - Start time
   - End time or duration
   - Description
5. **Save**: Click "Save Entry"

#### Time Entry Options

- **Manual Entry**: Enter start/end times
- **Duration Entry**: Enter total hours directly
- **Copy Previous**: Duplicate yesterday's entries
- **Bulk Entry**: Create multiple entries at once

#### Editing Time Entries

- Click on any time entry to edit
- Modify date, times, project, task, or description
- Save changes or delete entry
- View audit trail of changes

### Project Management

#### Viewing Projects

- **All Projects**: View all accessible projects
- **My Projects**: Projects you're assigned to
- **Enterprise Projects**: Organization-wide projects
- **Project Status**: Active, upcoming, or ended

#### Project Details

Each project shows:
- Project information and description
- Assigned team members
- Associated tasks
- Time tracking summary
- Project timeline and status

### Task Management

#### Creating Tasks

1. Select a project
2. Click "Create Task"
3. Enter task details:
   - Name and description
   - Status (active, completed, on-hold)
   - Assignees (optional)

#### Task Organization

- **Filter by Project**: View tasks for specific projects
- **Filter by Status**: Active, completed, or all tasks
- **Search**: Find tasks by name or description
- **Clone Tasks**: Copy tasks between projects

### Reporting

#### Available Reports

1. **Time Summary**: Total hours by date range
2. **Project Reports**: Hours breakdown by project
3. **Department Reports**: Team time summaries
4. **Individual Reports**: Personal time tracking
5. **Task Reports**: Time spent on specific tasks

#### Generating Reports

1. Navigate to "Reports" page
2. Select report type
3. Choose date range
4. Apply filters (project, department, employee)
5. View results and export if needed

---

## Administrative Guide

### User Management

#### User Roles

| Role | Capabilities |
|------|-------------|
| **Admin** | Full system access, user management, system configuration |
| **Manager** | Organization management, department oversight, all reporting |
| **Project Manager** | Project creation, team assignment, project reporting |
| **Employee** | Time entry, task management, personal reporting |
| **Viewer** | Read-only access to assigned projects and reports |

#### Managing Users

**Creating Users**:
1. Go to "User Management"
2. Click "Add User"
3. Enter user details and assign role
4. Set organization and department
5. Save user profile

**Editing Users**:
- Modify user roles and permissions
- Update organizational assignments
- Activate/deactivate accounts
- Reset sessions if needed

### Organization Management

#### Organization Structure

```
Organization
├── Departments
│   ├── Employees
│   └── Projects (department-specific)
└── Projects (organization-wide)
```

#### Managing Organizations

- Create and edit organizations
- Set organization hierarchies
- Assign users to organizations
- Configure organization-wide projects

#### Department Management

- Create departments within organizations
- Assign department managers
- Move employees between departments
- Track department-level time and projects

### Project Administration

#### Creating Projects

1. Go to "Projects" page
2. Click "Create Project"
3. Fill project details:
   - Name and description
   - Project number (optional)
   - Start and end dates
   - Color coding
   - Enterprise-wide flag
4. Assign team members
5. Create initial tasks

#### Project Settings

- **Enterprise-wide**: Available to all users
- **Department-specific**: Limited to department members
- **Private**: Only assigned users can access
- **Time tracking**: Enable/disable time tracking
- **Task management**: Configure task workflows

### System Administration

#### Health Monitoring

**Health Check Endpoints**:
- `/api/health` - General application health
- `/api/health/database` - Database connectivity
- `/api/health/saml` - SAML configuration

**Monitoring Commands**:
```powershell
# Check application status
npx pm2 status

# View application logs
npx pm2 logs fmb-timetracker

# Monitor real-time
npx pm2 monit
```

#### Database Administration

**Session Management**:
```sql
-- View active sessions
SELECT COUNT(*) as active_sessions FROM sessions WHERE expires > GETDATE();

-- Clean expired sessions
DELETE FROM sessions WHERE expires < GETDATE();

-- View session details
SELECT TOP 10 sid, expire, sess FROM sessions ORDER BY expire DESC;
```

**Performance Monitoring**:
```sql
-- Time entry statistics
SELECT 
    COUNT(*) as total_entries,
    SUM(duration) as total_hours,
    AVG(duration) as avg_hours
FROM time_entries 
WHERE date >= DATEADD(month, -1, GETDATE());

-- Project statistics
SELECT 
    p.name,
    COUNT(te.id) as entry_count,
    SUM(te.duration) as total_hours
FROM projects p
LEFT JOIN time_entries te ON p.id = te.project_id
GROUP BY p.id, p.name
ORDER BY total_hours DESC;
```

---

## Troubleshooting

### Common Issues

#### Database Connection Problems

**Symptoms**: Application fails to start, database connection errors

**Solutions**:
```powershell
# Test database connectivity
sqlcmd -S HUB-SQL1TST-LIS -U timetracker -P "password" -Q "SELECT 1"

# Check firewall
Test-NetConnection -ComputerName HUB-SQL1TST-LIS -Port 1433

# Verify environment variables
echo $env:FMB_DB_SERVER
echo $env:FMB_DB_USER
```

#### SAML Authentication Issues

**Symptoms**: Login redirects fail, SAML errors

**Solutions**:
1. **Verify Certificate**:
   ```powershell
   .\fmb-onprem\scripts\validate-saml-cert.ps1
   ```

2. **Check SAML Configuration**:
   - Verify Entity ID matches RSA configuration
   - Confirm ACS URL is accessible
   - Check certificate expiration

3. **Debug SAML Flow**:
   ```powershell
   # Enable SAML debugging
   $env:FMB_SAML_DEBUG = "true"
   npx pm2 restart fmb-timetracker
   ```

#### Application Startup Failures

**Symptoms**: PM2 shows failed status, application won't start

**Solutions**:
```powershell
# Check detailed logs
npx pm2 logs fmb-timetracker --lines 100

# Verify port availability
netstat -an | findstr :3000

# Check file permissions
icacls C:\fmb-timetracker /T /Q

# Validate configuration
node -p "JSON.stringify(process.env, null, 2)" | findstr FMB_
```

#### Session Management Issues

**Symptoms**: Users frequently logged out, session errors

**Solutions**:
```sql
-- Check session store health
SELECT 
    COUNT(*) as total_sessions,
    COUNT(CASE WHEN expires > GETDATE() THEN 1 END) as active_sessions,
    COUNT(CASE WHEN expires <= GETDATE() THEN 1 END) as expired_sessions
FROM sessions;

-- Clean up expired sessions
DELETE FROM sessions WHERE expires < DATEADD(hour, -24, GETDATE());
```

### Performance Issues

#### Slow Database Queries

**Diagnosis**:
```sql
-- Check for missing indexes
SELECT * FROM sys.dm_db_missing_index_details;

-- Monitor query performance
SELECT 
    s.text,
    p.execution_count,
    p.total_elapsed_time,
    p.avg_elapsed_time
FROM sys.dm_exec_query_stats p
CROSS APPLY sys.dm_exec_sql_text(p.sql_handle) s
ORDER BY p.avg_elapsed_time DESC;
```

**Solutions**:
- Add indexes on frequently queried columns
- Optimize time entry queries by date ranges
- Implement query result caching

#### High Memory Usage

**Monitoring**:
```powershell
# Check PM2 memory usage
npx pm2 monit

# Windows memory monitoring
Get-Process node | Select-Object ProcessName, WS, PM, VM
```

**Solutions**:
- Restart application during low usage periods
- Configure PM2 memory limits
- Optimize database connection pooling

### Error Code Reference

| Error Code | Description | Solution |
|------------|-------------|----------|
| `DB_CONNECTION_FAILED` | Database connection error | Check database server and credentials |
| `SAML_CERT_NOT_FOUND` | SAML certificate missing | Place certificate in correct location |
| `SESSION_STORE_ERROR` | Session storage failure | Check database sessions table |
| `AUTH_PROVIDER_ERROR` | SAML authentication failure | Verify RSA Identity Provider configuration |
| `PORT_IN_USE` | Application port conflict | Check for other processes using port 3000 |

---

## Development

### Development Setup

#### Local Development Environment

```powershell
# Clone repository
git clone <repository-url>
cd fmb-timetracker

# Install dependencies
npm install

# Copy environment template
copy .env.example .env

# Start development server
npm run dev
```

#### Development Scripts

```json
{
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "check": "tsc",
    "test": "vitest",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0"
  }
}
```

### Architecture Patterns

#### Backend Structure

```typescript
// Server architecture
server/
├── index.ts          # Application entry point
├── routes.ts         # API route definitions
├── storage.ts        # Database abstraction layer
├── auth/             # Authentication and authorization
├── middleware/       # Express middleware
└── types/           # TypeScript type definitions
```

#### Frontend Structure

```typescript
// Client architecture
client/src/
├── components/       # Reusable React components
├── pages/           # Page-level components
├── hooks/           # Custom React hooks
├── lib/             # Utility functions
└── types/           # TypeScript types
```

#### Database Layer

The application uses a custom storage abstraction:

```typescript
// Storage interface
interface StorageInterface {
  // User management
  getUser(id: string): Promise<User | null>;
  createUser(user: CreateUserData): Promise<User>;
  
  // Project management
  getProjects(): Promise<Project[]>;
  createProject(project: CreateProjectData): Promise<Project>;
  
  // Time tracking
  getTimeEntries(filters: TimeEntryFilters): Promise<TimeEntry[]>;
  createTimeEntry(entry: CreateTimeEntryData): Promise<TimeEntry>;
}
```

### API Endpoints

#### Authentication

- `GET /auth/status` - Check authentication status
- `GET /saml/login` - Initiate SAML login
- `POST /saml/acs` - SAML assertion consumer service
- `GET /saml/logout` - SAML logout

#### User Management

- `GET /api/users` - List users (admin only)
- `POST /api/users` - Create user (admin only)
- `PUT /api/users/:id` - Update user (admin only)
- `DELETE /api/users/:id` - Delete user (admin only)

#### Project Management

- `GET /api/projects` - List accessible projects
- `POST /api/projects` - Create project
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project
- `GET /api/projects/:id/employees` - List project employees
- `POST /api/projects/:id/employees` - Assign employee to project

#### Time Tracking

- `GET /api/time-entries` - List time entries
- `POST /api/time-entries` - Create time entry
- `PUT /api/time-entries/:id` - Update time entry
- `DELETE /api/time-entries/:id` - Delete time entry

#### Reporting

- `GET /api/reports/time-summary` - Time summary report
- `GET /api/reports/project/:id/time-entries` - Project time report
- `GET /api/reports/department/:id/summary` - Department summary

### Testing

#### Unit Tests

```typescript
// Example test
import { describe, it, expect } from 'vitest';
import { calculateDuration } from '../src/lib/timeUtils';

describe('Time Utilities', () => {
  it('should calculate duration correctly', () => {
    const duration = calculateDuration('09:00', '17:00');
    expect(duration).toBe(8);
  });
});
```

#### Integration Tests

```powershell
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test file
npm test -- auth.test.ts
```

---

## Security

### Security Architecture

#### Authentication Flow

1. **User Access**: User navigates to application
2. **SAML Redirect**: Application redirects to RSA Identity Provider
3. **User Authentication**: User authenticates with RSA
4. **SAML Response**: RSA sends signed SAML assertion
5. **Session Creation**: Application creates secure session
6. **Access Granted**: User gains access based on role

#### Authorization Model

```typescript
// Role-based permissions
const permissions = {
  admin: ['*'], // All permissions
  manager: ['read:all', 'write:organization', 'read:reports'],
  project_manager: ['read:projects', 'write:projects', 'read:reports'],
  employee: ['read:own', 'write:time_entries'],
  viewer: ['read:assigned']
};
```

### Security Best Practices

#### Database Security

- **Encrypted Connections**: All database traffic encrypted with TLS
- **Parameterized Queries**: SQL injection prevention
- **Least Privilege**: Database user has minimum required permissions
- **Connection Pooling**: Secure connection management

#### Session Security

- **Secure Cookies**: HttpOnly, Secure, SameSite attributes
- **Session Rotation**: Session IDs rotated on privilege changes
- **Timeout Management**: Automatic session expiration
- **Database Storage**: Sessions stored in encrypted database

#### SAML Security

- **Certificate Validation**: SAML responses verified with certificates
- **Assertion Validation**: Time-bound assertion checking
- **Signature Verification**: Digital signature validation
- **Replay Protection**: One-time use assertion enforcement

### Security Monitoring

#### Audit Logging

```sql
-- Security events logged
CREATE TABLE security_audit (
    id VARCHAR(50) PRIMARY KEY,
    event_type VARCHAR(100) NOT NULL,
    user_id VARCHAR(50),
    ip_address VARCHAR(45),
    user_agent TEXT,
    details TEXT,
    created_at DATETIME2 DEFAULT GETDATE()
);
```

#### Security Checks

```powershell
# Daily security validation
.\fmb-onprem\scripts\fmb-startup-validation.ps1

# Certificate expiration check
.\fmb-onprem\scripts\validate-saml-cert.ps1

# Session cleanup
sqlcmd -S HUB-SQL1TST-LIS -d timetracker -Q "DELETE FROM sessions WHERE expires < GETDATE()"
```

---

## Maintenance

### Regular Maintenance Tasks

#### Daily Tasks

1. **Health Checks**: Monitor application and database health
2. **Log Review**: Check for errors and security events
3. **Session Cleanup**: Remove expired sessions
4. **Backup Verification**: Ensure backups completed successfully

#### Weekly Tasks

1. **Performance Review**: Check query performance and system resources
2. **Security Updates**: Apply security patches if available
3. **Data Cleanup**: Remove old audit logs and temporary data
4. **Certificate Check**: Verify SAML certificate expiration

#### Monthly Tasks

1. **Full System Backup**: Complete backup of application and database
2. **Security Audit**: Review access logs and user permissions
3. **Performance Optimization**: Analyze and optimize slow queries
4. **Documentation Update**: Update procedures and configurations

### Backup Strategy

#### Database Backups

```sql
-- Full backup script
BACKUP DATABASE timetracker 
TO DISK = 'C:\Backups\timetracker_full.bak'
WITH FORMAT, COMPRESSION, STATS = 10;

-- Transaction log backup
BACKUP LOG timetracker 
TO DISK = 'C:\Backups\timetracker_log.trn'
WITH STATS = 10;
```

#### Application Backups

```powershell
# Application configuration backup
$BackupPath = "C:\Backups\FMB-TimeTracker-$(Get-Date -Format 'yyyyMMdd')"
New-Item -Path $BackupPath -ItemType Directory -Force

# Copy critical files
Copy-Item -Path "C:\fmb-timetracker\.env" -Destination $BackupPath
Copy-Item -Path "C:\fmb-timetracker\saml_cert.pem" -Destination $BackupPath
Copy-Item -Path "C:\fmb-timetracker\ecosystem.config.cjs" -Destination $BackupPath
```

### Update Procedures

#### Application Updates

```powershell
# Standard update procedure
.\fmb-onprem\scripts\fmb-deploy.ps1

# Clean deployment (full rebuild)
.\fmb-onprem\scripts\fmb-clean-deploy.ps1
```

#### Database Schema Updates

```sql
-- Apply schema migrations
-- Always backup before applying changes
BACKUP DATABASE timetracker TO DISK = 'C:\Backups\pre_migration.bak';

-- Apply migration scripts in order
-- Example: migrations/0003_new_feature.sql
```

### Performance Monitoring

#### Key Metrics

- **Response Time**: Average API response times
- **Database Performance**: Query execution times
- **Memory Usage**: Application memory consumption
- **Session Count**: Active user sessions
- **Error Rates**: Application error frequency

#### Monitoring Commands

```powershell
# Application performance
npx pm2 monit

# Database performance
sqlcmd -S HUB-SQL1TST-LIS -Q "SELECT * FROM sys.dm_exec_requests WHERE status = 'running'"

# System resources
Get-Counter "\Processor(_Total)\% Processor Time"
Get-Counter "\Memory\Available MBytes"
```

---

## API Reference

### Authentication

All API endpoints require authentication. Include session cookie or bearer token in requests.

#### Error Responses

```json
{
  "error": "Unauthorized",
  "message": "Authentication required",
  "code": 401
}
```

### User Management API

#### List Users
```http
GET /api/users
Authorization: Required (admin only)
```

**Response:**
```json
{
  "users": [
    {
      "id": "user-123",
      "email": "john.doe@fmb.com",
      "first_name": "John",
      "last_name": "Doe",
      "role": "employee",
      "is_active": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

#### Create User
```http
POST /api/users
Authorization: Required (admin only)
Content-Type: application/json
```

**Request:**
```json
{
  "email": "jane.doe@fmb.com",
  "first_name": "Jane",
  "last_name": "Doe",
  "role": "employee"
}
```

### Project Management API

#### List Projects
```http
GET /api/projects
Authorization: Required
```

**Query Parameters:**
- `status` - Filter by project status (active, upcoming, ended)
- `department` - Filter by department ID

#### Create Project
```http
POST /api/projects
Authorization: Required (project_manager, manager, admin)
Content-Type: application/json
```

**Request:**
```json
{
  "name": "New Project",
  "description": "Project description",
  "start_date": "2024-01-01",
  "end_date": "2024-12-31",
  "color": "#1976D2",
  "is_enterprise_wide": false
}
```

### Time Tracking API

#### List Time Entries
```http
GET /api/time-entries
Authorization: Required
```

**Query Parameters:**
- `start_date` - Start date filter (YYYY-MM-DD)
- `end_date` - End date filter (YYYY-MM-DD)
- `project_id` - Filter by project ID
- `user_id` - Filter by user ID (admin/manager only)

#### Create Time Entry
```http
POST /api/time-entries
Authorization: Required
Content-Type: application/json
```

**Request:**
```json
{
  "project_id": "project-123",
  "task_id": "task-456",
  "date": "2024-01-01",
  "start_time": "09:00",
  "end_time": "17:00",
  "description": "Working on feature development"
}
```

### Reports API

#### Time Summary Report
```http
GET /api/reports/time-summary
Authorization: Required
```

**Query Parameters:**
- `start_date` - Report start date
- `end_date` - Report end date
- `group_by` - Grouping option (day, week, month)

**Response:**
```json
{
  "summary": {
    "total_hours": 160.5,
    "total_entries": 42,
    "date_range": {
      "start": "2024-01-01",
      "end": "2024-01-31"
    }
  },
  "breakdown": [
    {
      "date": "2024-01-01",
      "hours": 8.0,
      "entries": 2
    }
  ]
}
```

#### Project Time Report
```http
GET /api/reports/project/{projectId}/time-entries
Authorization: Required
```

### Health Check API

#### Application Health
```http
GET /api/health
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "1.0.0",
  "environment": "production"
}
```

#### Database Health
```http
GET /api/health/database
```

**Response:**
```json
{
  "status": "healthy",
  "connection": "active",
  "response_time": "15ms",
  "pool_status": {
    "total": 10,
    "active": 2,
    "idle": 8
  }
}
```

---

## Appendix

### Useful Commands

#### PM2 Management
```powershell
npx pm2 start ecosystem.config.cjs    # Start application
npx pm2 restart fmb-timetracker       # Restart application
npx pm2 stop fmb-timetracker          # Stop application
npx pm2 logs fmb-timetracker          # View logs
npx pm2 monit                         # Monitor resources
npx pm2 save                          # Save configuration
```

#### Database Queries
```sql
-- User statistics
SELECT role, COUNT(*) as count FROM users GROUP BY role;

-- Project statistics
SELECT status, COUNT(*) as count FROM projects GROUP BY status;

-- Time entry statistics
SELECT DATE(date) as entry_date, COUNT(*) as entries, SUM(duration) as hours
FROM time_entries 
WHERE date >= DATEADD(week, -1, GETDATE())
GROUP BY DATE(date)
ORDER BY entry_date;
```

#### System Information
```powershell
# Check Node.js version
node --version

# Check application version
cat package.json | findstr version

# Check disk space
Get-WmiObject -Class Win32_LogicalDisk | Select-Object DeviceID, @{Name="Size(GB)";Expression={[math]::Round($_.Size/1GB,2)}}, @{Name="FreeSpace(GB)";Expression={[math]::Round($_.FreeSpace/1GB,2)}}

# Check memory usage
Get-WmiObject -Class Win32_ComputerSystem | Select-Object TotalPhysicalMemory
```

### Support Contacts

- **Application Issues**: FMB Development Team
- **Database Issues**: FMB SQL Server DBA Team
- **SAML/Authentication**: FMB Identity Management Team
- **Infrastructure**: FMB IT Infrastructure Team
- **Security**: FMB Information Security Team

### Change Log

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2024-01-01 | Initial release |
| 1.0.1 | 2024-01-15 | Bug fixes and performance improvements |
| 1.1.0 | 2024-02-01 | Enhanced reporting features |

---

**Last Updated**: January 2024  
**Version**: 1.0.0  
**Maintained By**: FMB Development Team
# FMB TimeTracker On-Premises Wiki

## Table of Contents
- [Overview](#overview)
- [Architecture](#architecture)
- [Installation Guide](#installation-guide)
- [Configuration](#configuration)
- [SAML Authentication](#saml-authentication)
- [Database Setup](#database-setup)
- [Deployment](#deployment)
- [Monitoring & Maintenance](#monitoring--maintenance)
- [Troubleshooting](#troubleshooting)
- [Security](#security)
- [API Reference](#api-reference)

---

## Overview

FMB TimeTracker is an enterprise-grade time tracking application designed for on-premises deployment with SAML SSO integration. Built with React frontend and Node.js backend, it provides comprehensive time tracking capabilities with role-based access control.

### Key Features
- **SAML 2.0 SSO Integration** - Enterprise authentication
- **Role-Based Access Control** - Admin, Manager, Employee roles
- **Time Entry Management** - Create, edit, and track time entries
- **Project & Task Management** - Hierarchical project structure
- **Department Management** - Organizational structure support
- **Reporting & Analytics** - Comprehensive time tracking reports
- **MS SQL Server Backend** - Enterprise database support

### Technology Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express, TypeScript
- **Database**: Microsoft SQL Server
- **Authentication**: SAML 2.0 with Passport.js
- **Session Management**: Express Session with SQL Server store

---

## Architecture

### System Components

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Web Browser   │◄──►│  FMB TimeTracker │◄──►│   SQL Server    │
│                 │    │   Application    │    │   Database      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌──────────────────┐
                       │   SAML IdP       │
                       │   (RSA/ADFS)     │
                       └──────────────────┘
```

### Application Structure
```
fmb-timetracker/
├── client/              # React frontend
├── server/              # Node.js backend
├── fmb-onprem/         # On-premises specific configurations
├── shared/             # Shared types and utilities
├── docs/               # Documentation
└── scripts/            # Deployment and maintenance scripts
```

---

## Installation Guide

### Prerequisites

#### Windows Server 2022 Requirements
- **Operating System**: Windows Server 2022
- **Node.js**: Version 18.x or higher
- **SQL Server**: 2019 or later
- **IIS**: Version 10 or later (for reverse proxy)
- **PowerShell**: Version 5.1 or later

#### Hardware Requirements
- **CPU**: 4+ cores
- **RAM**: 8GB minimum, 16GB recommended
- **Storage**: 100GB available space
- **Network**: Gigabit Ethernet

### Step 1: System Preparation

```powershell
# Enable required Windows features
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole
Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpRedirection
Enable-WindowsOptionalFeature -Online -FeatureName IIS-ApplicationDevelopment

# Install Node.js (download from nodejs.org)
# Verify installation
node --version
npm --version
```

### Step 2: Database Setup

```sql
-- Create database
CREATE DATABASE [timetracker]
GO

-- Create application user
CREATE LOGIN [timetracker_user] WITH PASSWORD = 'YourSecurePassword123!'
GO

USE [timetracker]
GO

CREATE USER [timetracker_user] FOR LOGIN [timetracker_user]
GO

-- Grant necessary permissions
ALTER ROLE [db_datareader] ADD MEMBER [timetracker_user]
ALTER ROLE [db_datawriter] ADD MEMBER [timetracker_user]
ALTER ROLE [db_ddladmin] ADD MEMBER [timetracker_user]
GO
```

### Step 3: Application Installation

```powershell
# Clone or extract application
cd C:\
git clone <repository-url> fmb-timetracker
cd fmb-timetracker

# Install dependencies
npm install

# Install PM2 globally for process management
npm install -g pm2
```

### Step 4: Configuration

Create and configure the environment file:

```powershell
# Copy template
copy fmb-onprem\.env.fmb-onprem.example fmb-onprem\.env.fmb-onprem
```

Edit `fmb-onprem/.env.fmb-onprem`:

```env
# Deployment Configuration
FMB_DEPLOYMENT=onprem
NODE_ENV=production

# Database Configuration
FMB_DB_SERVER=your-sql-server.domain.com
FMB_DB_NAME=timetracker
FMB_DB_USER=timetracker_user
FMB_DB_PASSWORD=YourSecurePassword123!
FMB_DB_PORT=1433
FMB_DB_ENCRYPT=true
FMB_DB_TRUST_SERVER_CERTIFICATE=true

# SAML Configuration
FMB_SAML_ENTITY_ID=https://timetracker.fmb.com
FMB_SAML_SSO_URL=https://rsa.fmb.com/saml/sso
FMB_SAML_ACS_URL=https://timetracker.fmb.com/saml/acs
FMB_SAML_CERT=./saml_cert.pem

# Security
FMB_SESSION_SECRET=your-super-secure-session-secret-32-plus-characters

# Server Configuration
FMB_PORT=3000
FMB_HOST=0.0.0.0
```

### Step 5: SAML Certificate Setup

Place your SAML certificate in the project root as `saml_cert.pem`:

```pem
-----BEGIN CERTIFICATE-----
[Your SAML Certificate Content Here]
-----END CERTIFICATE-----
```

### Step 6: Build and Deploy

```powershell
# Build application
npm run build

# Start with PM2
npm run start:pm2

# Save PM2 configuration
pm2 save
pm2 startup
```

---

## Configuration

### Environment Variables Reference

| Variable | Description | Required | Default | Example |
|----------|-------------|----------|---------|---------|
| `FMB_DEPLOYMENT` | Deployment type | Yes | `onprem` | `onprem` |
| `NODE_ENV` | Environment mode | Yes | `production` | `production` |
| `FMB_DB_SERVER` | SQL Server hostname | Yes | - | `sql.fmb.com` |
| `FMB_DB_NAME` | Database name | Yes | `timetracker` | `timetracker` |
| `FMB_DB_USER` | Database username | Yes | - | `timetracker_user` |
| `FMB_DB_PASSWORD` | Database password | Yes | - | `SecurePassword123!` |
| `FMB_DB_PORT` | Database port | No | `1433` | `1433` |
| `FMB_DB_ENCRYPT` | Enable encryption | No | `true` | `true` |
| `FMB_DB_TRUST_SERVER_CERTIFICATE` | Trust self-signed certs | No | `true` | `true` |
| `FMB_SAML_ENTITY_ID` | SAML entity identifier | Yes | - | `https://timetracker.fmb.com` |
| `FMB_SAML_SSO_URL` | SAML SSO endpoint | Yes | - | `https://rsa.fmb.com/saml/sso` |
| `FMB_SAML_ACS_URL` | SAML ACS callback URL | Yes | - | `https://timetracker.fmb.com/saml/acs` |
| `FMB_SAML_CERT` | SAML certificate path | Yes | - | `./saml_cert.pem` |
| `FMB_SESSION_SECRET` | Session encryption key | Yes | - | `32+ character string` |
| `FMB_PORT` | Application port | No | `3000` | `3000` |
| `FMB_HOST` | Bind address | No | `0.0.0.0` | `0.0.0.0` |
| `ADMIN_USERS` | Admin user emails | No | - | `admin@fmb.com,manager@fmb.com` |

### IIS Reverse Proxy Configuration

```xml
<!-- web.config for IIS reverse proxy -->
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="FMB TimeTracker" stopProcessing="true">
          <match url=".*" />
          <action type="Rewrite" url="http://localhost:3000/{R:0}" />
        </rule>
      </rules>
    </rewrite>
  </system.webServer>
</configuration>
```

---

## SAML Authentication

### SAML Configuration Overview

FMB TimeTracker uses SAML 2.0 for enterprise authentication. The application acts as a Service Provider (SP) and integrates with your Identity Provider (IdP).

### SAML Endpoints

| Endpoint | URL | Purpose |
|----------|-----|---------|
| **Metadata** | `/api/saml/metadata` | SP metadata for IdP configuration |
| **SSO Login** | `/api/saml/login` | Initiate SAML login |
| **ACS Callback** | `/saml/acs` | Assertion Consumer Service |
| **Logout** | `/api/logout` | Application logout |

### Identity Provider Setup

#### Required SAML Attributes

| Attribute | Required | Description | Example |
|-----------|----------|-------------|---------|
| `nameID` or `email` | Yes | User email/identifier | `john.doe@fmb.com` |
| `firstName` or `givenName` | No | First name | `John` |
| `lastName` or `surname` | No | Last name | `Doe` |
| `department` | No | Department name | `Engineering` |
| `employeeId` | No | Employee identifier | `EMP001` |

#### SAML Configuration Parameters

For your Identity Provider configuration:

- **Entity ID**: Value from `FMB_SAML_ENTITY_ID`
- **ACS URL**: Value from `FMB_SAML_ACS_URL`
- **Name ID Format**: `urn:oasis:names:tc:SAML:2.0:nameid-format:persistent`
- **Binding**: `HTTP-POST`

### User Role Assignment

```typescript
// Automatic role assignment logic
const adminUsers = process.env.ADMIN_USERS?.split(',') || [];
const userRole = adminUsers.includes(email) ? 'admin' : 'employee';
```

---

## Database Setup

### Schema Overview

The application uses a normalized database schema with the following main entities:

#### Core Tables

```sql
-- Users table
CREATE TABLE users (
    id NVARCHAR(255) PRIMARY KEY,
    email NVARCHAR(255) UNIQUE NOT NULL,
    first_name NVARCHAR(255),
    last_name NVARCHAR(255),
    role NVARCHAR(50) CHECK (role IN ('admin', 'manager', 'employee')),
    organization_id NVARCHAR(255),
    department NVARCHAR(255),
    is_active BIT DEFAULT 1,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

-- Projects table
CREATE TABLE projects (
    id NVARCHAR(255) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NTEXT,
    organization_id NVARCHAR(255),
    is_active BIT DEFAULT 1,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

-- Tasks table
CREATE TABLE tasks (
    id NVARCHAR(255) PRIMARY KEY,
    title NVARCHAR(255) NOT NULL,
    description NTEXT,
    project_id NVARCHAR(255),
    assigned_to NVARCHAR(255),
    status NVARCHAR(50) DEFAULT 'open',
    estimated_hours DECIMAL(10,2),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
);

-- Time entries table
CREATE TABLE time_entries (
    id NVARCHAR(255) PRIMARY KEY,
    user_id NVARCHAR(255) NOT NULL,
    project_id NVARCHAR(255),
    task_id NVARCHAR(255),
    hours DECIMAL(10,2) NOT NULL,
    date DATE NOT NULL,
    description NTEXT,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (task_id) REFERENCES tasks(id)
);
```

### Database Migration

Run the initial setup script:

```powershell
# Navigate to scripts directory
cd fmb-onprem/scripts

# Run complete setup
sqlcmd -S your-server -d timetracker -i fmb-complete-setup.sql
```

---

## Deployment

### Production Deployment Process

#### 1. Pre-Deployment Checklist

```powershell
# Run validation script
.\scripts\fmb-production-check.js

# Verify SAML configuration
.\scripts\validate-saml-config.js

# Check database connectivity
npm run db:test
```

#### 2. Deployment Steps

```powershell
# Stop existing application
pm2 stop fmb-timetracker

# Backup current deployment
Copy-Item -Path "C:\fmb-timetracker" -Destination "C:\fmb-timetracker-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')" -Recurse

# Deploy new version
git pull origin main
npm install
npm run build

# Start application
pm2 start ecosystem.config.cjs
```

#### 3. Post-Deployment Verification

```powershell
# Check application health
curl http://localhost:3000/health

# Verify SAML metadata
curl http://localhost:3000/api/saml/metadata

# Check logs
pm2 logs fmb-timetracker
```

### PM2 Process Management

```javascript
// ecosystem.config.cjs
module.exports = {
  apps: [{
    name: 'fmb-timetracker',
    script: './dist/index.js',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    max_memory_restart: '1G'
  }]
};
```

---

## Monitoring & Maintenance

### Health Monitoring

#### Application Health Endpoint

```bash
# Health check endpoint
GET /health

# Response format
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "database": "connected",
  "message": "FMB Database connection established",
  "environment": "fmb-onprem",
  "version": "1.0.0-fmb"
}
```

#### Key Metrics to Monitor

- **Application Status**: Health endpoint response
- **Database Connectivity**: Connection pool status
- **SAML Authentication**: Login success/failure rates
- **Session Management**: Active sessions count
- **Memory Usage**: Application memory consumption
- **Disk Space**: Available storage space

### Log Management

#### Log Files Location

```
C:\fmb-timetracker\logs\
├── err.log          # Error logs
├── out.log          # Standard output
├── combined.log     # Combined logs
└── pm2.log         # PM2 process logs
```

#### Log Analysis Commands

```powershell
# View recent errors
Get-Content .\logs\err.log -Tail 50

# Monitor live logs
pm2 logs fmb-timetracker --lines 100

# Search for specific errors
Select-String -Path .\logs\combined.log -Pattern "ERROR"
```

### Database Maintenance

#### Regular Maintenance Tasks

```sql
-- Update database statistics
UPDATE STATISTICS users;
UPDATE STATISTICS time_entries;
UPDATE STATISTICS projects;
UPDATE STATISTICS tasks;

-- Rebuild indexes (monthly)
ALTER INDEX ALL ON users REBUILD;
ALTER INDEX ALL ON time_entries REBUILD;

-- Check database integrity
DBCC CHECKDB('timetracker');
```

#### Backup Strategy

```powershell
# Daily backup script
$BackupPath = "C:\Backups\TimeTracker"
$Date = Get-Date -Format "yyyyMMdd"
$BackupFile = "$BackupPath\timetracker_$Date.bak"

sqlcmd -Q "BACKUP DATABASE timetracker TO DISK = '$BackupFile'"
```

---

## Troubleshooting

### Common Issues

#### 1. SAML Certificate Not Found

**Error**: `SAML certificate file not found`

**Solution**:
```powershell
# Verify certificate file exists
Test-Path .\saml_cert.pem

# Check certificate format
Get-Content .\saml_cert.pem | Select-String "BEGIN CERTIFICATE"

# Validate certificate path in config
echo $env:FMB_SAML_CERT
```

#### 2. Database Connection Failed

**Error**: `Failed to connect to FMB database`

**Solution**:
```powershell
# Test database connectivity
sqlcmd -S $env:FMB_DB_SERVER -U $env:FMB_DB_USER -P $env:FMB_DB_PASSWORD -Q "SELECT 1"

# Check firewall settings
Test-NetConnection -ComputerName $env:FMB_DB_SERVER -Port 1433

# Verify SQL Server is running
Get-Service MSSQLSERVER
```

#### 3. SAML Authentication Fails

**Error**: `SAML authentication failed`

**Troubleshooting Steps**:
```powershell
# Check SAML metadata
curl http://localhost:3000/api/saml/metadata

# Verify IdP configuration matches
# Check application logs for SAML errors
pm2 logs fmb-timetracker | Select-String "SAML"

# Test SAML certificate
.\scripts\validate-saml-config.js
```

#### 4. Session Store Errors

**Error**: `Session store connection failed`

**Solution**:
```powershell
# Check session table exists
sqlcmd -Q "SELECT COUNT(*) FROM sessions"

# Recreate session table if needed
sqlcmd -i .\migrations\create-sessions-table.sql

# Restart application
pm2 restart fmb-timetracker
```

### Debug Mode

Enable debug logging:

```env
# Add to .env.fmb-onprem
DEBUG=fmb:*
LOG_LEVEL=debug
```

### Performance Troubleshooting

#### High Memory Usage

```powershell
# Check PM2 memory usage
pm2 monit

# Analyze memory leaks
pm2 logs fmb-timetracker | Select-String "memory"

# Restart if memory exceeds threshold
pm2 restart fmb-timetracker
```

#### Slow Database Queries

```sql
-- Enable query statistics
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

-- Analyze slow queries
SELECT TOP 10 
    total_elapsed_time/execution_count AS avg_elapsed_time,
    text
FROM sys.dm_exec_query_stats 
CROSS APPLY sys.dm_exec_sql_text(sql_handle)
ORDER BY avg_elapsed_time DESC;
```

---

## Security

### Security Best Practices

#### 1. Network Security

- **Firewall Configuration**: Restrict access to required ports only
- **SSL/TLS**: Use HTTPS in production with valid certificates
- **Network Segmentation**: Isolate application and database servers

#### 2. Application Security

- **Session Management**: Secure session configuration with httpOnly cookies
- **Input Validation**: All user inputs are validated and sanitized
- **SQL Injection Prevention**: Parameterized queries throughout
- **XSS Protection**: Content Security Policy headers enabled

#### 3. Authentication Security

- **SAML Security**: Certificate-based authentication with IdP
- **Session Timeouts**: Configurable session and inactivity timeouts
- **Role-Based Access**: Granular permissions based on user roles

#### 4. Database Security

```sql
-- Database security configuration
-- Enable transparent data encryption
ALTER DATABASE timetracker SET ENCRYPTION ON;

-- Configure backup encryption
BACKUP DATABASE timetracker 
TO DISK = 'C:\Backups\timetracker.bak'
WITH ENCRYPTION (
    ALGORITHM = AES_256,
    SERVER CERTIFICATE = TimeTrackerBackupCert
);
```

### Security Monitoring

#### Failed Login Attempts

```sql
-- Monitor authentication failures
SELECT 
    email,
    COUNT(*) as failed_attempts,
    MAX(created_at) as last_attempt
FROM audit_logs 
WHERE event_type = 'SAML_AUTH_FAILED'
    AND created_at >= DATEADD(hour, -24, GETDATE())
GROUP BY email
HAVING COUNT(*) > 5;
```

#### Privilege Escalation Detection

```sql
-- Monitor role changes
SELECT 
    user_id,
    old_role,
    new_role,
    changed_by,
    created_at
FROM audit_logs 
WHERE event_type = 'USER_ROLE_CHANGED'
ORDER BY created_at DESC;
```

---

## API Reference

### Authentication Endpoints

#### POST `/api/login`
Initiate SAML authentication

**Response**: Redirect to IdP

#### POST `/saml/acs`
SAML Assertion Consumer Service

**Parameters**: SAML response from IdP
**Response**: Redirect to application dashboard

#### GET `/api/logout`
User logout

**Response**: Redirect to login page

### User Management

#### GET `/api/users`
Get all users (Admin only)

**Response**:
```json
{
  "users": [
    {
      "id": "user-123",
      "email": "john.doe@fmb.com",
      "first_name": "John",
      "last_name": "Doe",
      "role": "employee",
      "department": "Engineering",
      "is_active": true
    }
  ]
}
```

#### PUT `/api/users/:id`
Update user (Admin/Manager only)

**Request Body**:
```json
{
  "role": "manager",
  "department": "Engineering",
  "is_active": true
}
```

### Project Management

#### GET `/api/projects`
Get user's projects

**Query Parameters**:
- `include_inactive`: Include inactive projects

#### POST `/api/projects`
Create new project (Admin/Manager only)

**Request Body**:
```json
{
  "name": "New Project",
  "description": "Project description",
  "organization_id": "org-fmb"
}
```

### Time Entry Management

#### GET `/api/time-entries`
Get time entries

**Query Parameters**:
- `start_date`: Filter start date (YYYY-MM-DD)
- `end_date`: Filter end date (YYYY-MM-DD)
- `project_id`: Filter by project
- `user_id`: Filter by user (Manager/Admin only)

#### POST `/api/time-entries`
Create time entry

**Request Body**:
```json
{
  "project_id": "project-123",
  "task_id": "task-456",
  "hours": 8.5,
  "date": "2024-01-15",
  "description": "Development work"
}
```

### Reports

#### GET `/api/reports/summary`
Get time summary report

**Query Parameters**:
- `period`: `week`, `month`, `quarter`, `year`
- `group_by`: `user`, `project`, `department`

**Response**:
```json
{
  "summary": {
    "total_hours": 160.5,
    "billable_hours": 140.0,
    "entries_count": 32
  },
  "breakdown": [
    {
      "group": "Engineering",
      "hours": 80.25,
      "percentage": 50.0
    }
  ]
}
```

### Health & System

#### GET `/health`
Application health check

#### GET `/api/saml/metadata`
SAML metadata XML

---

## Appendices

### A. Configuration Templates

#### Complete Environment Configuration

```env
# FMB TimeTracker On-Premises Configuration
# Copy this to fmb-onprem/.env.fmb-onprem and customize

# Deployment Type
FMB_DEPLOYMENT=onprem
NODE_ENV=production

# Database Configuration
FMB_DB_SERVER=sql.fmb.com
FMB_DB_NAME=timetracker
FMB_DB_USER=timetracker_user
FMB_DB_PASSWORD=YourSecurePassword123!
FMB_DB_PORT=1433
FMB_DB_ENCRYPT=true
FMB_DB_TRUST_SERVER_CERTIFICATE=true

# SAML Authentication
FMB_SAML_ENTITY_ID=https://timetracker.fmb.com
FMB_SAML_SSO_URL=https://rsa.fmb.com/saml/sso
FMB_SAML_ACS_URL=https://timetracker.fmb.com/saml/acs
FMB_SAML_CERT=./saml_cert.pem
FMB_SAML_ISSUER=https://timetracker.fmb.com
FMB_SAML_NAME_ID_FORMAT=urn:oasis:names:tc:SAML:2.0:nameid-format:persistent
FMB_SAML_BINDING=urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST

# Session Security
FMB_SESSION_SECRET=your-super-secure-session-secret-minimum-32-characters-long

# Server Configuration
FMB_PORT=3000
FMB_HOST=0.0.0.0

# Admin Users (comma-separated)
ADMIN_USERS=admin@fmb.com,it.admin@fmb.com

# Optional: Debug Settings
# DEBUG=fmb:*
# LOG_LEVEL=info
```

### B. Deployment Scripts

#### Quick Deployment Script

```powershell
# fmb-quick-deploy.ps1
param(
    [string]$InstallPath = "C:\fmb-timetracker",
    [string]$BackupPath = "C:\Backups\TimeTracker"
)

Write-Host "🚀 FMB TimeTracker Quick Deployment" -ForegroundColor Green

# Create backup
$BackupDir = "$BackupPath\backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
if (Test-Path $InstallPath) {
    Copy-Item -Path $InstallPath -Destination $BackupDir -Recurse -Force
    Write-Host "✅ Backup created: $BackupDir" -ForegroundColor Green
}

# Stop application
pm2 stop fmb-timetracker 2>$null

# Pull latest changes
Set-Location $InstallPath
git pull origin main

# Install dependencies and build
npm install
npm run build

# Start application
pm2 start ecosystem.config.cjs
pm2 save

Write-Host "🎉 Deployment completed successfully!" -ForegroundColor Green
Write-Host "🔍 Check status: pm2 status" -ForegroundColor Yellow
Write-Host "📊 View logs: pm2 logs fmb-timetracker" -ForegroundColor Yellow
```

### C. Maintenance Scripts

#### Database Maintenance Script

```sql
-- fmb-maintenance.sql
-- Monthly database maintenance script

USE timetracker;
GO

-- Update statistics
PRINT 'Updating database statistics...';
UPDATE STATISTICS users;
UPDATE STATISTICS time_entries;
UPDATE STATISTICS projects;
UPDATE STATISTICS tasks;
UPDATE STATISTICS sessions;

-- Reindex tables
PRINT 'Rebuilding indexes...';
ALTER INDEX ALL ON users REBUILD;
ALTER INDEX ALL ON time_entries REBUILD;
ALTER INDEX ALL ON projects REBUILD;
ALTER INDEX ALL ON tasks REBUILD;

-- Clean old sessions (older than 30 days)
PRINT 'Cleaning expired sessions...';
DELETE FROM sessions 
WHERE expires < DATEADD(day, -30, GETDATE());

-- Check database integrity
PRINT 'Checking database integrity...';
DBCC CHECKDB('timetracker') WITH NO_INFOMSGS;

PRINT 'Maintenance completed successfully!';
```

---

## Support & Contact

For technical support and assistance:

- **Internal IT Support**: Contact your IT department
- **Application Issues**: Check troubleshooting section first
- **Database Issues**: Contact your DBA team
- **SAML/Authentication**: Contact your Identity Management team

---

*Last Updated: January 2024*
*Version: 1.0.0*
